import { auth } from '@/lib/auth';
import { prisma } from '@majestic/database';
import { redirect } from 'next/navigation';
import { TestResult } from '@/components/tests/test-result';

// Роли с доступом к полному разбору
const REVIEW_ROLES = [
  '1482048390136070329',
  '1482048390148784234',
  '1550899527450632362',
  '1482048390157303913',
  '1482048390157303914',
];

function hasReviewAccess(userRoles: any[] | null | undefined): boolean {
  if (!userRoles || !Array.isArray(userRoles)) return false;
  return userRoles.some((role: any) => REVIEW_ROLES.includes(role.id));
}

async function getAttempt(attemptId: string) {
  return await prisma.testAttempt.findUnique({
    where: { id: attemptId },
    include: {
      test: {
        include: {
          questions: {
            orderBy: { order: 'asc' },
          },
        },
      },
      user: {
        select: {
          username: true,
          displayName: true,
          discordId: true,
          avatar: true,
        },
      },
    },
  });
}

export default async function TestResultPage({
  params,
}: {
  params: Promise<{ id: string; attemptId: string }>;
}) {
  const { id, attemptId } = await params;
  const session = await auth();
  if (!session?.user?.id) {
    redirect('/login');
  }

  const attempt = await getAttempt(attemptId);
  if (!attempt) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Результат не найден</h1>
          <p className="text-muted-foreground">
            Проверьте правильность ссылки
          </p>
        </div>
      </div>
    );
  }

  // Проверяем права на просмотр детального разбора
  const canSeeDetails = 
    hasReviewAccess(session.user.discordRoles) || 
    attempt.test.showReview ||
    attempt.userId === session.user.id;

  return (
    <TestResult 
      attempt={attempt} 
      canSeeDetails={canSeeDetails}
      isOwner={attempt.userId === session.user.id}
    />
  );
}
