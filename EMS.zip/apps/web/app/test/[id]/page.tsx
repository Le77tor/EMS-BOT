import { auth } from '@/lib/auth';
import { prisma } from '@majestic/database';
import { redirect } from 'next/navigation';
import { TestTaking } from '@/components/tests/test-taking';

async function getTest(id: string) {
  return await prisma.test.findUnique({
    where: { id },
    include: {
      questions: {
        orderBy: { order: 'asc' },
      },
      creator: {
        select: {
          username: true,
          displayName: true,
        },
      },
    },
  });
}

async function getLastAttempt(testId: string, userId: string) {
  return await prisma.testAttempt.findFirst({
    where: {
      testId,
      userId,
      completedAt: { not: null },
    },
    orderBy: { completedAt: 'desc' },
  });
}

export default async function TestPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await auth();
  if (!session?.user?.id) {
    redirect('/login');
  }

  const test = await getTest(id);
  if (!test) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Тест не найден</h1>
          <p className="text-muted-foreground">
            Проверьте правильность ссылки
          </p>
        </div>
      </div>
    );
  }

  if (test.status !== 'PUBLISHED') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Тест не опубликован</h1>
          <p className="text-muted-foreground">
            Этот тест находится в черновиках
          </p>
        </div>
      </div>
    );
  }

  // Проверяем доступ по ролям
  const accessRoles = test.accessRoles ? JSON.parse(test.accessRoles as string) : null;
  if (accessRoles && Array.isArray(accessRoles)) {
    const userRoles = session.user.discordRoles || [];
    const hasAccess = Array.isArray(userRoles) && userRoles.some((role: any) => 
      accessRoles.includes(role.id)
    );

    if (!hasAccess) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-2">Нет доступа</h1>
            <p className="text-muted-foreground">
              Этот тест доступен только для определённых отделов
            </p>
          </div>
        </div>
      );
    }
  }

  // Проверяем последнюю попытку и задержку между попытками
  const lastAttempt = await getLastAttempt(id, session.user.id);
  if (lastAttempt && test.retryDelay > 0 && !lastAttempt.passed) {
    const nextAttemptTime = new Date(
      lastAttempt.completedAt!.getTime() + test.retryDelay * 60 * 1000
    );
    const now = new Date();

    if (now < nextAttemptTime) {
      const remainingTime = Math.ceil(
        (nextAttemptTime.getTime() - now.getTime()) / 60000
      );
      const hours = Math.floor(remainingTime / 60);
      const minutes = remainingTime % 60;

      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center max-w-md">
            <h1 className="text-3xl font-bold mb-2">Повторная попытка недоступна</h1>
            <p className="text-muted-foreground mb-4">
              Следующая попытка будет доступна через:
            </p>
            <p className="text-4xl font-bold text-primary">
              {hours > 0 && `${hours} ч `}
              {minutes} мин
            </p>
            <p className="text-sm text-muted-foreground mt-4">
              Вы не сдали предыдущую попытку. Пауза между попытками: {Math.floor(test.retryDelay / 60)} ч {test.retryDelay % 60} мин
            </p>
          </div>
        </div>
      );
    }
  }

  return <TestTaking test={test} userId={session.user.id} />;
}
