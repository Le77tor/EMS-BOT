import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { prisma } from '@majestic/database';

export async function GET() {
  try {
    const session = await auth();
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const userId = (session.user as any).id;
    
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        discordId: true,
        username: true,
        displayName: true,
        discriminator: true,
        email: true,
        avatar: true,
      },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Fetch fresh data from Discord
    let discordData = null;
    try {
      const account = await prisma.account.findFirst({
        where: { userId: user.id },
        select: { access_token: true },
      });

      if (account?.access_token) {
        const response = await fetch('https://discord.com/api/users/@me', {
          headers: {
            Authorization: `Bearer ${account.access_token}`,
          },
        });
        
        if (response.ok) {
          discordData = await response.json();
        }
      }
    } catch (error) {
      console.error('Failed to fetch Discord data:', error);
    }

    return NextResponse.json({
      database: user,
      discord: discordData,
      session: session.user,
    });
  } catch (error) {
    console.error('User info error:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: String(error) },
      { status: 500 }
    );
  }
}
