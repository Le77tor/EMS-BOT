import { NextResponse } from 'next/server';
import { prisma } from '@majestic/database';

/**
 * POST /api/discord/join-guild
 * Добавляет пользователя на Discord сервер после подачи заявки
 * Вызывается из API /api/applications/employment сразу после создания заявки
 */
export async function POST(request: Request) {
  try {
    const { applicationId } = await request.json();

    if (!applicationId) {
      return NextResponse.json(
        { error: 'Не указан ID заявки' },
        { status: 400 }
      );
    }

    console.log(`📋 Processing join-guild request for application: ${applicationId}`);

    // Получаем заявку
    const application = await prisma.employmentApplication.findUnique({
      where: { id: applicationId }
    });

    if (!application) {
      console.log(`❌ Application not found: ${applicationId}`);
      return NextResponse.json(
        { error: 'Заявка не найдена' },
        { status: 404 }
      );
    }

    console.log(`✅ Found application for Discord ID: ${application.discordId}`);

    // Получаем пользователя по Discord ID
    const user = await prisma.user.findUnique({
      where: { discordId: application.discordId }
    });

    if (!user) {
      console.log(`❌ User not found for Discord ID: ${application.discordId}`);
      return NextResponse.json(
        { error: 'Пользователь не найден в системе' },
        { status: 404 }
      );
    }

    // Получаем access token пользователя из БД
    const account = await prisma.account.findFirst({
      where: {
        userId: user.id,
        provider: 'discord'
      }
    });

    if (!account?.access_token) {
      console.log(`❌ No access token found for user: ${user.id}`);
      return NextResponse.json(
        { error: 'Не найден Discord токен. Пользователь должен авторизоваться заново.' },
        { status: 400 }
      );
    }

    console.log(`✅ Found access token for user: ${user.id}`, {
      tokenPreview: account.access_token.substring(0, 20) + '...',
      scope: account.scope,
      expiresAt: account.expires_at
    });

    // ID вашего Discord сервера - HARDCODED т.к. Hostinger не применяет env переменные
    const GUILD_ID = '1482048390119555123';
    
    console.log('🔧 Using HARDCODED GUILD_ID:', GUILD_ID);

    // ✅ ИСПРАВЛЕНО: используем DISCORD_TOKEN вместо DISCORD_BOT_TOKEN
    const botToken = process.env.DISCORD_TOKEN;
    
    if (!botToken) {
      console.error('❌ DISCORD_TOKEN не установлен в .env');
      return NextResponse.json(
        { error: 'Ошибка конфигурации сервера' },
        { status: 500 }
      );
    }

    console.log(`🔄 Adding user ${application.discordId} to guild ${GUILD_ID}...`);
    console.log(`🔑 Using bot token: ${botToken.substring(0, 20)}...`);
    console.log(`🎫 Using user access token: ${account.access_token.substring(0, 20)}...`);

    // Discord API: Add Guild Member
    // https://discord.com/developers/docs/resources/guild#add-guild-member
    const apiUrl = `https://discord.com/api/v10/guilds/${GUILD_ID}/members/${application.discordId}`;
    console.log(`📡 Discord API URL: ${apiUrl}`);

    const discordResponse = await fetch(apiUrl, {
      method: 'PUT',
      headers: {
        'Authorization': `Bot ${botToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        access_token: account.access_token,
      }),
    });

    console.log(`📥 Discord API response status: ${discordResponse.status}`);
    console.log(`📥 Discord API response headers:`, Object.fromEntries(discordResponse.headers.entries()));

    // Статус 201 = пользователь добавлен
    // Статус 204 = пользователь уже на сервере
    // Другие статусы = ошибка
    if (discordResponse.status === 201) {
      console.log(`✅ User ${application.discordId} successfully added to guild`);
    } else if (discordResponse.status === 204) {
      console.log(`✅ User ${application.discordId} is already in the guild`);
    } else if (!discordResponse.ok) {
      const errorText = await discordResponse.text();
      let errorData: any = {};
      
      try {
        errorData = JSON.parse(errorText);
      } catch {
        errorData = { rawError: errorText };
      }
      
      console.error('❌ Discord API error:', {
        status: discordResponse.status,
        statusText: discordResponse.statusText,
        error: errorData,
        headers: Object.fromEntries(discordResponse.headers.entries())
      });
      
      return NextResponse.json(
        { 
          error: 'Не удалось добавить на сервер Discord',
          details: errorData.message || errorText || 'Неизвестная ошибка',
          code: errorData.code,
          status: discordResponse.status
        },
        { status: discordResponse.status }
      );
    }

    // Обновляем статус заявки
    await prisma.employmentApplication.update({
      where: { id: applicationId },
      data: {
        userJoinedGuild: true,
        updatedAt: new Date()
      }
    });

    console.log(`✅ Updated application ${applicationId} - userJoinedGuild: true`);

    return NextResponse.json({
      success: true,
      message: 'Пользователь успешно добавлен на сервер'
    });

  } catch (error) {
    console.error('❌ Ошибка при добавлении на сервер:', error);
    return NextResponse.json(
      { 
        error: 'Внутренняя ошибка сервера',
        details: error instanceof Error ? error.message : String(error)
      },
      { status: 500 }
    );
  }
}
