import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    DISCORD_CLIENT_ID: process.env.DISCORD_CLIENT_ID || 'NOT SET',
    DISCORD_GUILD_ID: process.env.DISCORD_GUILD_ID || 'NOT SET',
    DISCORD_TOKEN: process.env.DISCORD_TOKEN ? `${process.env.DISCORD_TOKEN.substring(0, 20)}...` : 'NOT SET',
    NODE_ENV: process.env.NODE_ENV,
  });
}
