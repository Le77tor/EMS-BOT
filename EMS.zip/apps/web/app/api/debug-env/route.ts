import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    hasNextAuthUrl: !!process.env.NEXTAUTH_URL,
    hasNextAuthSecret: !!process.env.NEXTAUTH_SECRET,
    hasDiscordClientId: !!process.env.DISCORD_CLIENT_ID,
    hasDiscordClientSecret: !!process.env.DISCORD_CLIENT_SECRET,
    nextAuthUrlLength: process.env.NEXTAUTH_URL?.length || 0,
    // НЕ показываем сами значения для безопасности
    environment: process.env.NODE_ENV,
  });
}
