import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@majestic/database';

export async function POST(req: NextRequest) {
  try {
    console.log('[transfer-api] 📥 Received transfer application request');

    // Проверка авторизации
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      console.log('[transfer-api] ❌ Unauthorized');
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    console.log('[transfer-api] ✅ User authenticated:', session.user.id);

    // Получаем данные из запроса
    const body = await req.json();
    const { targetDepartment, online, schedule, experience, motivation } = body;

    console.log('[transfer-api] 📝 Application data:', { 
      targetDepartment, 
      online, 
      schedule, 
      experience: experience?.substring(0, 50) + '...', 
      motivation: motivation?.substring(0, 50) + '...' 
    });

    // Валидация
    if (!targetDepartment || !online || !schedule || !experience || !motivation) {
      console.log('[transfer-api] ❌ Missing required fields');
      return NextResponse.json(
        { error: 'All fields are required' },
        { status: 400 }
      );
    }

    // Проверка валидности отдела
    const validDepartments = ['DI', 'HAD', 'PSED', 'DES', 'PM'];
    if (!validDepartments.includes(targetDepartment)) {
      console.log('[transfer-api] ❌ Invalid department:', targetDepartment);
      return NextResponse.json(
        { error: 'Invalid department. Must be one of: DI, HAD, PSED, DES, PM' },
        { status: 400 }
      );
    }

    // Проверка минимальной длины текстов
    if (experience.length < 20 || experience.length > 1000) {
      console.log('[transfer-api] ❌ Invalid experience length:', experience.length);
      return NextResponse.json(
        { error: 'Experience must be between 20 and 1000 characters' },
        { status: 400 }
      );
    }

    if (motivation.length < 20 || motivation.length > 1000) {
      console.log('[transfer-api] ❌ Invalid motivation length:', motivation.length);
      return NextResponse.json(
        { error: 'Motivation must be between 20 and 1000 characters' },
        { status: 400 }
      );
    }

    // Создаем заявку в базе данных
    const application = await prisma.application.create({
      data: {
        userId: session.user.id,
        type: 'TRANSFER',
        status: 'PENDING',
        data: {
          targetDepartment,
          online,
          schedule,
          experience,
          motivation,
        },
      },
    });

    console.log('[transfer-api] ✅ Transfer application created:', application.id);

    // TODO: Отправить уведомление в Discord бот для обработки
    // Discord бот автоматически обработает эту заявку через WebSocket или polling

    return NextResponse.json({
      success: true,
      applicationId: application.id,
      message: 'Transfer application submitted successfully',
    });
  } catch (error) {
    console.error('[transfer-api] ❌ Error creating transfer application:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
