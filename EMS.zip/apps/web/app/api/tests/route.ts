import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { prisma, Prisma } from '@majestic/database';

// Роли с доступом к созданию тестов
const TEST_CREATOR_ROLES = [
  '1482048390157303914', // Лидер
  '1482048390157303913', // Зам. Лидера
  '1550078792813256754', // Куратор
  '1518978875059732601', // Куратор Мл. Состава
  '1518626611921027244', // Глава Отдела Дисциплины
];

function hasCreatorAccess(userRoles: any[] | null | undefined): boolean {
  if (!userRoles || !Array.isArray(userRoles)) return false;
  return userRoles.some((role: any) => TEST_CREATOR_ROLES.includes(role.id));
}

// GET /api/tests - Получить список тестов
export async function GET(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const tests = await prisma.test.findMany({
      where: { status: { in: ['PUBLISHED', 'DRAFT'] } },
      include: {
        creator: {
          select: {
            username: true,
            displayName: true,
          },
        },
        questions: {
          select: { id: true },
        },
        attempts: {
          select: { id: true, passed: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(tests);
  } catch (error) {
    console.error('[API] Error fetching tests:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST /api/tests - Создать новый тест
export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Проверяем права доступа
    if (!hasCreatorAccess(session.user.discordRoles)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const {
      title,
      description,
      status,
      accessRoles,
      passingScore,
      timeLimit,
      questionsPerAttempt,
      retryDelay,
      shuffleQuestions,
      shuffleAnswers,
      showReview,
      questions,
    } = body;

    // Валидация
    if (!title || !questions || questions.length === 0) {
      return NextResponse.json(
        { error: 'Title and questions are required' },
        { status: 400 }
      );
    }

    // Создаём тест с вопросами
    const test = await prisma.test.create({
      data: {
        title,
        description,
        status: status || 'DRAFT',
        accessRoles: accessRoles ? JSON.stringify(accessRoles) : Prisma.DbNull,
        passingScore: passingScore || 70,
        timeLimit: timeLimit || null,
        questionsPerAttempt: questionsPerAttempt || null,
        retryDelay: retryDelay || 0,
        shuffleQuestions: shuffleQuestions || false,
        shuffleAnswers: shuffleAnswers || false,
        showReview: showReview || false,
        createdBy: session.user.id,
        publishedAt: status === 'PUBLISHED' ? new Date() : null,
        questions: {
          create: questions.map((q: any, index: number) => ({
            question: q.question,
            type: q.type || 'MULTIPLE_CHOICE',
            options: JSON.stringify(q.options),
            explanation: q.explanation || null,
            points: 1,
            order: q.order !== undefined ? q.order : index,
          })),
        },
      },
      include: {
        questions: true,
      },
    });

    console.log(`[API] Test created: ${test.id} by ${session.user.id}`);

    return NextResponse.json(test, { status: 201 });
  } catch (error) {
    console.error('[API] Error creating test:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PUT /api/tests/[id] - Обновить тест
export async function PUT(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Проверяем права доступа
    if (!hasCreatorAccess(session.user.discordRoles)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const {
      id,
      title,
      description,
      status,
      accessRoles,
      passingScore,
      timeLimit,
      questionsPerAttempt,
      retryDelay,
      shuffleQuestions,
      shuffleAnswers,
      showReview,
      questions,
    } = body;

    if (!id) {
      return NextResponse.json(
        { error: 'Test ID is required' },
        { status: 400 }
      );
    }

    // Удаляем старые вопросы и создаём новые
    await prisma.question.deleteMany({
      where: { testId: id },
    });

    const test = await prisma.test.update({
      where: { id },
      data: {
        title,
        description,
        status,
        accessRoles: accessRoles ? JSON.stringify(accessRoles) : Prisma.DbNull,
        passingScore,
        timeLimit,
        questionsPerAttempt,
        retryDelay,
        shuffleQuestions,
        shuffleAnswers,
        showReview,
        publishedAt: status === 'PUBLISHED' ? new Date() : null,
        questions: {
          create: questions.map((q: any, index: number) => ({
            question: q.question,
            type: q.type || 'MULTIPLE_CHOICE',
            options: JSON.stringify(q.options),
            explanation: q.explanation || null,
            points: 1,
            order: q.order !== undefined ? q.order : index,
          })),
        },
      },
      include: {
        questions: true,
      },
    });

    console.log(`[API] Test updated: ${test.id} by ${session.user.id}`);

    return NextResponse.json(test);
  } catch (error) {
    console.error('[API] Error updating test:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE /api/tests/[id] - Удалить тест
export async function DELETE(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Проверяем права доступа
    if (!hasCreatorAccess(session.user.discordRoles)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'Test ID is required' },
        { status: 400 }
      );
    }

    await prisma.test.delete({
      where: { id },
    });

    console.log(`[API] Test deleted: ${id} by ${session.user.id}`);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('[API] Error deleting test:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
