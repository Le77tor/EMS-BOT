import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { prisma } from '@majestic/database';

// POST /api/tests/submit - Отправить ответы на тест
export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { testId, answers } = body;

    if (!testId || !answers) {
      return NextResponse.json(
        { error: 'Test ID and answers are required' },
        { status: 400 }
      );
    }

    // Получаем тест с вопросами
    const test = await prisma.test.findUnique({
      where: { id: testId },
      include: {
        questions: true,
      },
    });

    if (!test) {
      return NextResponse.json({ error: 'Test not found' }, { status: 404 });
    }

    // Подсчитываем результат
    let correctAnswers = 0;
    const totalQuestions = answers.length;

    answers.forEach((answer: any) => {
      const question = test.questions.find((q) => q.id === answer.questionId);
      if (!question) return;

      const options = JSON.parse(question.options as string);
      const correctOptions = options
        .map((opt: any, index: number) => (opt.isCorrect ? index : -1))
        .filter((i: number) => i !== -1)
        .sort();

      const userAnswers = (answer.selectedOptions || []).sort();

      // Сравниваем массивы
      const isCorrect =
        correctOptions.length === userAnswers.length &&
        correctOptions.every((val: number, index: number) => val === userAnswers[index]);

      if (isCorrect) {
        correctAnswers++;
      }
    });

    const score = totalQuestions > 0 ? (correctAnswers / totalQuestions) * 100 : 0;
    const passed = score >= test.passingScore;

    // Сохраняем попытку
    const attempt = await prisma.testAttempt.create({
      data: {
        testId: test.id,
        userId: session.user.id,
        answers: JSON.stringify(answers),
        score,
        passed,
        correctAnswers,
        totalQuestions,
        completedAt: new Date(),
      },
    });

    console.log(
      `[API] Test submitted: ${test.id} by ${session.user.id}, score: ${score.toFixed(1)}%, passed: ${passed}`
    );

    return NextResponse.json({
      attemptId: attempt.id,
      score,
      passed,
      correctAnswers,
      totalQuestions,
    });
  } catch (error) {
    console.error('[API] Error submitting test:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
