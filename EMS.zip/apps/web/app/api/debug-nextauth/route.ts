import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    NEXTAUTH_URL: process.env.NEXTAUTH_URL,
    NEXTAUTH_URL_length: process.env.NEXTAUTH_URL?.length,
    NEXTAUTH_URL_charCodes: process.env.NEXTAUTH_URL?.split('').map((c, i) => `${i}:${c}(${c.charCodeAt(0)})`),
    NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET ? '✅ SET' : '❌ NOT SET',
    DISCORD_CLIENT_ID: process.env.DISCORD_CLIENT_ID ? '✅ SET' : '❌ NOT SET',
    DISCORD_CLIENT_SECRET: process.env.DISCORD_CLIENT_SECRET ? '✅ SET' : '❌ NOT SET',
    NODE_ENV: process.env.NODE_ENV,
  });
}
