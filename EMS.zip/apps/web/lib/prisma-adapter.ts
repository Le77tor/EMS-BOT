import type { Adapter, AdapterUser, AdapterAccount, AdapterSession, VerificationToken } from 'next-auth/adapters';
import { PrismaClient } from '@majestic/database';

/**
 * Custom Prisma Adapter for NextAuth.js
 * Работает с кастомной схемой User (без unique email)
 */
export function CustomPrismaAdapter(prisma: PrismaClient): Adapter {
  return {
    // ==========================================
    // User methods
    // ==========================================
    
    async createUser(data: Omit<AdapterUser, 'id'>): Promise<AdapterUser> {
      // Не используется, т.к. пользователи создаются в signIn callback
      throw new Error('createUser not implemented - users are created in signIn callback');
    },

    async getUser(id: string): Promise<AdapterUser | null> {
      const user = await prisma.user.findUnique({
        where: { id },
      });

      if (!user) return null;

      return {
        id: user.id,
        email: user.email || '',
        emailVerified: null,
        name: user.displayName || user.username,
        image: user.avatar ? `https://cdn.discordapp.com/avatars/${user.discordId}/${user.avatar}.png` : null,
        discordId: user.discordId,
      } as AdapterUser;
    },

    async getUserByEmail(email: string): Promise<AdapterUser | null> {
      // Используем findFirst вместо findUnique
      const user = await prisma.user.findFirst({
        where: { email },
      });

      if (!user) return null;

      return {
        id: user.id,
        email: user.email || '',
        emailVerified: null,
        name: user.displayName || user.username,
        image: user.avatar ? `https://cdn.discordapp.com/avatars/${user.discordId}/${user.avatar}.png` : null,
        discordId: user.discordId,
      } as AdapterUser;
    },

    async getUserByAccount({ providerAccountId, provider }: Pick<AdapterAccount, 'provider' | 'providerAccountId'>): Promise<AdapterUser | null> {
      const account = await prisma.account.findUnique({
        where: {
          provider_providerAccountId: {
            provider,
            providerAccountId,
          },
        },
        include: { user: true },
      });

      if (!account?.user) return null;

      const user = account.user;
      return {
        id: user.id,
        email: user.email || '',
        emailVerified: null,
        name: user.displayName || user.username,
        image: user.avatar ? `https://cdn.discordapp.com/avatars/${user.discordId}/${user.avatar}.png` : null,
        discordId: user.discordId,
      } as AdapterUser;
    },

    async updateUser(user: Partial<AdapterUser> & Pick<AdapterUser, 'id'>): Promise<AdapterUser> {
      const updated = await prisma.user.update({
        where: { id: user.id },
        data: {
          email: user.email,
          displayName: user.name,
        },
      });

      return {
        id: updated.id,
        email: updated.email || '',
        emailVerified: null,
        name: updated.displayName || updated.username,
        image: updated.avatar ? `https://cdn.discordapp.com/avatars/${updated.discordId}/${updated.avatar}.png` : null,
        discordId: updated.discordId,
      } as AdapterUser;
    },

    async deleteUser(userId: string): Promise<void> {
      await prisma.user.delete({
        where: { id: userId },
      });
    },

    // ==========================================
    // Account methods
    // ==========================================

    async linkAccount(account: AdapterAccount): Promise<AdapterAccount | null | undefined> {
      await prisma.account.create({
        data: {
          userId: account.userId,
          type: account.type,
          provider: account.provider,
          providerAccountId: account.providerAccountId,
          refresh_token: account.refresh_token,
          access_token: account.access_token,
          expires_at: account.expires_at,
          token_type: account.token_type,
          scope: account.scope,
          id_token: account.id_token,
          session_state: account.session_state as string | undefined,
        },
      });

      return account;
    },

    async unlinkAccount({ providerAccountId, provider }: Pick<AdapterAccount, 'provider' | 'providerAccountId'>): Promise<void> {
      await prisma.account.delete({
        where: {
          provider_providerAccountId: {
            provider,
            providerAccountId,
          },
        },
      });
    },

    // ==========================================
    // Session methods
    // ==========================================

    async createSession(session: { sessionToken: string; userId: string; expires: Date }): Promise<AdapterSession> {
      const created = await prisma.session.create({
        data: session,
      });

      return {
        sessionToken: created.sessionToken,
        userId: created.userId,
        expires: created.expires,
      };
    },

    async getSessionAndUser(sessionToken: string): Promise<{ session: AdapterSession; user: AdapterUser } | null> {
      const userAndSession = await prisma.session.findUnique({
        where: { sessionToken },
        include: { user: true },
      });

      if (!userAndSession) return null;

      const { user, ...session } = userAndSession;
      
      return {
        session: {
          sessionToken: session.sessionToken,
          userId: session.userId,
          expires: session.expires,
        },
        user: {
          id: user.id,
          email: user.email || '',
          emailVerified: null,
          name: user.displayName || user.username,
          image: user.avatar ? `https://cdn.discordapp.com/avatars/${user.discordId}/${user.avatar}.png` : null,
          discordId: user.discordId,
        } as AdapterUser,
      };
    },

    async updateSession(session: Partial<AdapterSession> & Pick<AdapterSession, 'sessionToken'>): Promise<AdapterSession | null | undefined> {
      const updated = await prisma.session.update({
        where: { sessionToken: session.sessionToken },
        data: {
          expires: session.expires,
        },
      });

      return {
        sessionToken: updated.sessionToken,
        userId: updated.userId,
        expires: updated.expires,
      };
    },

    async deleteSession(sessionToken: string): Promise<void> {
      await prisma.session.delete({
        where: { sessionToken },
      });
    },

    // ==========================================
    // Verification Token methods
    // ==========================================

    async createVerificationToken(verificationToken: VerificationToken): Promise<VerificationToken | null | undefined> {
      const created = await prisma.verificationToken.create({
        data: verificationToken,
      });

      return {
        identifier: created.identifier,
        token: created.token,
        expires: created.expires,
      };
    },

    async useVerificationToken({ identifier, token }: { identifier: string; token: string }): Promise<VerificationToken | null> {
      try {
        const verificationToken = await prisma.verificationToken.delete({
          where: {
            identifier_token: {
              identifier,
              token,
            },
          },
        });

        return {
          identifier: verificationToken.identifier,
          token: verificationToken.token,
          expires: verificationToken.expires,
        };
      } catch (error) {
        return null;
      }
    },
  };
}
