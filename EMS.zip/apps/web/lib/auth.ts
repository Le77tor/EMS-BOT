import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/pages/api/auth/[...nextauth]';

// Экспортируем authOptions для использования в других местах
export { authOptions };

export const auth = () => getServerSession(authOptions);
