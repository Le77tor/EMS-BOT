import NextAuth, { NextAuthOptions } from 'next-auth';
import DiscordProvider from 'next-auth/providers/discord';
import { prisma } from '@majestic/database';
import { UserRole } from '@majestic/shared';

export const authOptions: NextAuthOptions = {
  // ❌ УБРАЛИ АДАПТЕР - он не нужен с JWT strategy!
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30 days
    updateAge: 0, // Always update session
  },
  
  providers: [
    // 🔒 Discord Provider для ГЛАВНОГО ВХОДА (с проверкой роли EMS)
    DiscordProvider({
      id: 'discord',
      name: 'Discord',
      clientId: process.env.DISCORD_CLIENT_ID || '1550804035915878420',
      clientSecret: process.env.DISCORD_CLIENT_SECRET || 'bJfe-aKNxys_hpDs9VFUGixbcgy416R6',
      authorization: {
        params: {
          scope: 'identify email guilds guilds.members.read guilds.join',
        },
      },
      issuer: 'https://discord.com',
      token: 'https://discord.com/api/oauth2/token',
      userinfo: 'https://discord.com/api/users/@me',
    }),
    
    // 🌐 Discord Provider для ПУБЛИЧНЫХ ФОРМ (БЕЗ проверки роли EMS)
    DiscordProvider({
      id: 'discord-public',
      name: 'Discord (Public)',
      clientId: process.env.DISCORD_CLIENT_ID || '1550804035915878420',
      clientSecret: process.env.DISCORD_CLIENT_SECRET || 'bJfe-aKNxys_hpDs9VFUGixbcgy416R6',
      authorization: {
        params: {
          scope: 'identify email guilds guilds.members.read guilds.join',
        },
      },
      issuer: 'https://discord.com',
      token: 'https://discord.com/api/oauth2/token',
      userinfo: 'https://discord.com/api/users/@me',
    }),
  ],
  
  secret: process.env.NEXTAUTH_SECRET || 'a8f3c9d2e1b7f4a6c8e2d5b9f1a3c7e4',
  
  pages: {
    signIn: '/login',
    error: '/login',
  },
  
  callbacks: {
    async signIn({ user, account, profile }) {
      if (!account || !profile) {
        console.error('[auth] Missing account or profile');
        return false;
      }

      try {
        const discordProfile = profile as any;
        // Hardcoded Guild ID - твой Discord сервер
        const guildId = '1482048390119555123';
        
        console.log('[auth] 🔍 Checking bot configuration:', {
          botTokenExists: !!process.env.DISCORD_TOKEN,
          botTokenLength: process.env.DISCORD_TOKEN?.length || 0,
          guildId: guildId,
          userId: discordProfile.id,
        });
        
        // Логируем что пришло от Discord
        console.log('[auth] Discord profile data:', {
          id: discordProfile.id,
          username: discordProfile.username,
          global_name: discordProfile.global_name,
          discriminator: discordProfile.discriminator,
        });
        
        // Получаем серверный никнейм
        let displayName = discordProfile.global_name || discordProfile.username || '';
        
        try {
          // Правильный endpoint для получения данных члена сервера
          const apiUrl = `https://discord.com/api/v10/guilds/${guildId}/members/${discordProfile.id}`;
          console.log('[auth] 📡 Fetching guild member from:', apiUrl);
          
          const guildMemberResponse = await fetch(apiUrl, {
            headers: {
              Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
            },
          });
          
          console.log('[auth] Guild member response status:', guildMemberResponse.status);
          
          if (guildMemberResponse.ok) {
            const guildMember = await guildMemberResponse.json();
            console.log('[auth] Guild member data:', JSON.stringify(guildMember, null, 2));
            
            // Используем серверный никнейм если есть
            if (guildMember.nick) {
              displayName = guildMember.nick;
              console.log('[auth] ✅ Using server nickname:', displayName);
            } else {
              console.log('[auth] ⚠️ No server nickname found, using global name');
            }
          } else {
            const errorText = await guildMemberResponse.text();
            console.error('[auth] ❌ Failed to fetch guild member:', {
              status: guildMemberResponse.status,
              error: errorText
            });
          }
        } catch (guildError) {
          console.error('[auth] Error fetching guild member:', guildError);
        }
        
        console.log('[auth] Final displayName:', displayName);
        console.log('[auth] 💾 Saving to database...');
        
        // Получаем роли пользователя с сервера Discord
        let discordRoles = null;
        let isMemberOfGuild = false; // ✅ Флаг: является ли членом сервера
        try {
          const rolesApiUrl = `https://discord.com/api/v10/guilds/${guildId}/members/${discordProfile.id}`;
          const rolesResponse = await fetch(rolesApiUrl, {
            headers: {
              Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
            },
          });
          
          if (rolesResponse.ok) {
            isMemberOfGuild = true; // ✅ Член сервера
            const memberData = await rolesResponse.json();
            const roleIds = memberData.roles || [];
            
            // Получаем информацию о ролях сервера
            const guildRolesUrl = `https://discord.com/api/v10/guilds/${guildId}/roles`;
            const guildRolesResponse = await fetch(guildRolesUrl, {
              headers: {
                Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
              },
            });
            
            if (guildRolesResponse.ok) {
              const allRoles = await guildRolesResponse.json();
              // Фильтруем роли пользователя
              discordRoles = allRoles
                .filter((role: any) => roleIds.includes(role.id))
                .map((role: any) => ({
                  id: role.id,
                  name: role.name,
                  color: role.color,
                  position: role.position
                }))
                .sort((a: any, b: any) => b.position - a.position); // Сортируем по позиции (важные роли выше)
              
              console.log('[auth] ✅ Discord roles fetched:', discordRoles.length, 'roles');
            }
          } else {
            console.error('[auth] ❌ User is NOT a member of the guild. Status:', rolesResponse.status);
          }
        } catch (rolesError) {
          console.error('[auth] Error fetching Discord roles:', rolesError);
        }
        
        // Проверяем существует ли пользователь
        const existingUser = await prisma.user.findUnique({
          where: { discordId: account.providerAccountId },
        });
        
        console.log('[auth] Existing user before upsert:', existingUser ? {
          id: existingUser.id,
          username: existingUser.username,
          displayName: existingUser.displayName
        } : 'NOT FOUND');
        
        const updateData = {
          username: discordProfile.username || '',
          displayName: displayName,
          discriminator: discordProfile.discriminator || '0',
          avatar: discordProfile.avatar || null,
          email: profile.email || null,
          lastLoginAt: new Date(),
          discordRoles: discordRoles,
        };
        
        console.log('[auth] Update data to be saved:', updateData);
        
        // ✅ Создаём/обновляем пользователя
        const dbUser = await prisma.user.upsert({
          where: { discordId: account.providerAccountId },
          create: {
            discordId: account.providerAccountId,
            ...updateData,
            role: UserRole.MEMBER,
          },
          update: updateData,
        });
        
        console.log('[auth] ✅ User saved:', {
          id: dbUser.id,
          username: dbUser.username,
          displayName: dbUser.displayName
        });
        
        // ✅ Создаём/обновляем account запись с токенами
        console.log('[auth] 💾 Saving account with tokens...');
        
        await prisma.account.upsert({
          where: {
            provider_providerAccountId: {
              provider: account.provider,
              providerAccountId: account.providerAccountId,
            },
          },
          create: {
            userId: dbUser.id,
            type: account.type,
            provider: account.provider,
            providerAccountId: account.providerAccountId,
            refresh_token: account.refresh_token,
            access_token: account.access_token,
            expires_at: account.expires_at,
            token_type: account.token_type,
            scope: account.scope,
            id_token: account.id_token,
            session_state: account.session_state as string | undefined,
          },
          update: {
            refresh_token: account.refresh_token,
            access_token: account.access_token,
            expires_at: account.expires_at,
            token_type: account.token_type,
            scope: account.scope,
            id_token: account.id_token,
            session_state: account.session_state as string | undefined,
          },
        });
        
        console.log('[auth] ✅ Account saved with tokens:', {
          provider: account.provider,
          userId: dbUser.id,
          access_token: account.access_token ? `${account.access_token.substring(0, 20)}...` : 'NULL',
          refresh_token: account.refresh_token ? 'YES' : 'NO',
          scope: account.scope,
        });

        // Store user data in the user object for JWT
        user.id = dbUser.id;
        (user as any).displayName = dbUser.displayName;
        (user as any).username = dbUser.username;
        (user as any).role = dbUser.role;
        (user as any).status = dbUser.status;
        (user as any).discordId = dbUser.discordId;
        (user as any).avatar = dbUser.avatar;
        (user as any).discordRoles = dbUser.discordRoles;
        
        console.log('[auth] 📦 Stored in user object for JWT:', {
          id: user.id,
          displayName: (user as any).displayName,
          username: (user as any).username,
          discordRoles: (user as any).discordRoles?.length || 0
        });

        // 🔒 ПРОВЕРКА РОЛИ EMS (1482048390119555125)
        // ⚠️ ТОЛЬКО для главного входа (provider === 'discord')
        // ✅ Для публичных форм (provider === 'discord-public') пропускаем проверку
        const EMS_ROLE_ID = '1482048390119555125';
        
        if (account.provider === 'discord') {
          console.log('[auth] 🔒 Main login - checking EMS role...');
          
          // ❗ СНАЧАЛА проверяем, что человек ВООБЩЕ на сервере
          if (!isMemberOfGuild) {
            console.error('[auth] ❌ User is NOT a member of the Discord server!');
            return '/login?error=NotOnServer'; // ✅ Редирект с ошибкой
          }
          
          // ✅ Человек на сервере → проверяем роль
          const hasEmsRole = discordRoles && Array.isArray(discordRoles) 
            ? discordRoles.some((role: any) => role.id === EMS_ROLE_ID)
            : false;

          if (!hasEmsRole) {
            console.error('[auth] ❌ User does not have EMS role:', EMS_ROLE_ID);
            console.error('[auth] User roles:', discordRoles?.map((r: any) => `${r.name} (${r.id})`).join(', ') || 'NONE');
            return '/login?error=NoEmsRole'; // ✅ Редирект с ошибкой
          }

          console.log('[auth] ✅ User has EMS role, access granted');
        } else if (account.provider === 'discord-public') {
          console.log('[auth] ⚠️ Public form access - role check SKIPPED');
        }
        return true;
      } catch (error) {
        console.error('[auth] Sign in error:', error);
        return false;
      }
    },
    
    async jwt({ token, user, account, profile, trigger }) {
      // Initial sign in - use data from user object (just set in signIn callback)
      if (user) {
        console.log('[jwt] Initial sign in - storing user data in token:', {
          id: user.id,
          displayName: (user as any).displayName,
          username: (user as any).username,
          discordRoles: (user as any).discordRoles?.length || 0
        });
        
        // FORCE UPDATE - always use fresh data from user object
        token.id = user.id;
        token.role = (user as any).role;
        token.status = (user as any).status;
        token.discordId = (user as any).discordId;
        token.displayName = (user as any).displayName;
        token.username = (user as any).username;
        token.avatar = (user as any).avatar;
        token.discordRoles = (user as any).discordRoles;
        
        console.log('[jwt] ✅ Token FORCE updated with fresh data:', {
          displayName: token.displayName,
          username: token.username,
          discordRoles: (token.discordRoles as any)?.length || 0
        });
      }

      console.log('[jwt] Final token state:', {
        id: token.id,
        displayName: token.displayName,
        username: token.username,
        avatar: token.avatar,
        discordId: token.discordId,
        discordRoles: (token.discordRoles as any)?.length || 0
      });
      
      return token;
    },
    
    async session({ session, token }) {
      if (session.user && token) {
        console.log('[session] Using data from JWT token:', {
          id: token.id,
          displayName: token.displayName,
          username: token.username,
          discordRoles: (token.discordRoles as any)?.length || 0
        });
        
        // Используем данные из JWT токена (НЕ из БД)
        (session.user as any).id = token.id;
        (session.user as any).role = token.role;
        (session.user as any).status = token.status;
        (session.user as any).discordId = token.discordId;
        (session.user as any).username = token.username;
        (session.user as any).displayName = token.displayName;
        (session.user as any).discordRoles = token.discordRoles;
        
        // Устанавливаем name из displayName
        session.user.name = (token.displayName as string) || (token.username as string);
        
        console.log('[session] Session user.name set to:', session.user.name);
        console.log('[session] Discord roles passed:', (token.discordRoles as any)?.length || 0);
        
        // Обновляем аватар из Discord если есть
        if (token.avatar && token.discordId) {
          session.user.image = `https://cdn.discordapp.com/avatars/${token.discordId}/${token.avatar}.png`;
          console.log('[session] Avatar URL generated:', session.user.image);
        } else {
          console.log('[session] No avatar data:', { avatar: token.avatar, discordId: token.discordId });
        }
      }
      return session;
    },
  },
  
  debug: true,
};

export default NextAuth(authOptions);
