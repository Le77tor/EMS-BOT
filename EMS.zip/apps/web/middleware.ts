import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  // Исправляем headers для NextAuth за прокси
  const requestHeaders = new Headers(request.headers);
  
  // Устанавливаем правильный host
  requestHeaders.set('x-forwarded-host', 'yellow-lemur-271988.hostingersite.com');
  requestHeaders.set('x-forwarded-proto', 'https');
  requestHeaders.set('host', 'yellow-lemur-271988.hostingersite.com');
  
  // Логируем для отладки
  if (request.nextUrl.pathname.startsWith('/api/auth')) {
    console.log('[middleware] Auth request:', {
      pathname: request.nextUrl.pathname,
      host: requestHeaders.get('host'),
      'x-forwarded-host': requestHeaders.get('x-forwarded-host'),
      'x-forwarded-proto': requestHeaders.get('x-forwarded-proto'),
    });
  }
  
  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
  });
}

export const config = {
  matcher: '/api/auth/:path*',
};
