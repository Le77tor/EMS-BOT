'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Users,
  ClipboardList,
  GraduationCap,
  BarChart3,
  Menu,
  X,
} from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';
import { useSession } from 'next-auth/react';

// 🔒 Роли для доступа к разделам
const APPLICATIONS_ROLES = [
  '1482048390157303914', // Лидер
  '1482048390157303913', // Зам. Лидера
  '1550078792813256754', // Куратор
  '1518978875059732601', // Куратор Мл. Состава
  // '1482048390148784230', // Отдел HAD - НЕ ДОЛЖЕН ВИДЕТЬ Заявки
  // '1482048390119555125', // EMS - ОТКЛЮЧЕН
];

const USERS_ROLES = [
  '1482048390157303914', // Лидер
  '1482048390157303913', // Зам. Лидера
  '1550078792813256754', // Кураторы
  '1518978875059732601', // Куратор Мл. Состава
  '1518626611921027244', // Глава Отдела Дисциплины
  '1482048390148784230', // Отдел HAD
];

const HR_STATS_ROLES = [
  '1482048390157303914', // Лидер
  '1482048390157303913', // Зам. Лидера
  '1550078792813256754', // Кураторы
  '1518978875059732601', // Куратор Мл. Состава
  '1518626611921027244', // Глава Отдела Дисциплины
  '1482048390148784230', // ✅ Добавлена новая роль
  // '1482048390119555125', // EMS - ОТКЛЮЧЕН
];

// Проверка наличия хотя бы одной роли из списка
function hasAnyRole(userRoles: any[] | null | undefined, requiredRoles: string[]): boolean {
  console.log('[hasAnyRole] Checking roles:', {
    userRolesCount: userRoles?.length || 0,
    requiredRolesCount: requiredRoles.length,
    userRoleIds: userRoles?.map((r: any) => r.id) || [],
    requiredRoleIds: requiredRoles
  });
  
  if (!userRoles || !Array.isArray(userRoles)) {
    console.log('[hasAnyRole] ❌ No user roles provided');
    return false;
  }
  
  const result = userRoles.some((role: any) => {
    const hasRole = requiredRoles.includes(role.id);
    console.log(`[hasAnyRole] Checking role ${role.id} (${role.name}): ${hasRole ? '✅ MATCH' : '❌ no match'}`);
    return hasRole;
  });
  
  console.log('[hasAnyRole] Final result:', result);
  return result;
}

const navigation = [
  { name: 'Главная', href: '/dashboard', icon: LayoutDashboard, requiredRoles: null },
  { name: 'Пользователи', href: '/dashboard/users', icon: Users, requiredRoles: USERS_ROLES },
  { name: 'Заявки', href: '/dashboard/applications', icon: ClipboardList, requiredRoles: APPLICATIONS_ROLES },
  { name: 'Тесты', href: '/dashboard/tests', icon: GraduationCap, requiredRoles: null },
  { name: 'Отдел Дисциплины', href: '/dashboard/hr-stats', icon: BarChart3, requiredRoles: HR_STATS_ROLES },
];

interface SidebarProps {
  userRoles?: any[] | null;
}

export function Sidebar({ userRoles }: SidebarProps) {
  const pathname = usePathname();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  
  // 🧪 DEBUG: Проверяем роли пользователя
  console.log('='.repeat(80));
  console.log('[sidebar] 🔍 SIDEBAR DEBUG:');
  console.log('[sidebar] userRoles received:', userRoles);
  console.log('[sidebar] userRoles type:', typeof userRoles);
  console.log('[sidebar] userRoles is Array?', Array.isArray(userRoles));
  console.log('[sidebar] userRoles length:', userRoles?.length || 0);
  if (userRoles && userRoles.length > 0) {
    console.log('[sidebar] First role:', userRoles[0]);
    console.log('[sidebar] Role IDs:', userRoles.map((r: any) => r.id));
  }
  console.log('='.repeat(80));
  
  // Фильтруем навигацию по доступным ролям
  const filteredNavigation = navigation.filter(item => {
    if (!item.requiredRoles) {
      console.log(`[sidebar] ✅ "${item.name}" - доступно всем`);
      return true;
    }
    
    const hasAccess = hasAnyRole(userRoles, item.requiredRoles);
    console.log(`[sidebar] ${hasAccess ? '✅' : '❌'} "${item.name}" - required:`, item.requiredRoles.slice(0, 2), 'hasAccess:', hasAccess);
    return hasAccess;
  });
  
  console.log('[sidebar] Filtered navigation count:', filteredNavigation.length, 'out of', navigation.length);

  return (
    <>
      {/* Mobile menu button */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 md:hidden"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
      >
        {isMobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </Button>

      {/* Overlay */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed md:static inset-y-0 left-0 z-40 w-72 bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-950 border-r border-border/50 transition-transform duration-300 ease-in-out md:translate-x-0',
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-border/50">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl blur-lg opacity-50" />
                <div className="relative bg-gradient-to-br from-blue-600 to-purple-700 p-2.5 rounded-xl shadow-lg">
                  <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5zm0 18c-3.86-.93-6-4.85-6-8V8.3l6-3 6 3V12c0 3.15-2.14 7.07-6 8z"/>
                    <circle cx="12" cy="12" r="3"/>
                  </svg>
                </div>
              </div>
              <div>
                <h2 className="text-xl font-black bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Majestic
                </h2>
                <p className="text-xs text-muted-foreground font-medium">CMS v1.0</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto p-4 space-y-1">
            {filteredNavigation.map((item) => {
              const isActive = pathname === item.href;
              const Icon = item.icon;

              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setIsMobileOpen(false)}
                  className={cn(
                    'flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 group relative overflow-hidden',
                    isActive
                      ? 'bg-primary/10 text-primary border border-primary/20'
                      : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                  )}
                >

                  <Icon className={cn(
                    'h-5 w-5 transition-transform duration-200',
                    isActive ? 'scale-110' : 'group-hover:scale-110'
                  )} />
                  <span className="relative">{item.name}</span>
                  {isActive && (
                    <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Footer */}
          <div className="p-4 border-t border-border/50">
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 rounded-xl p-4 border border-blue-200/50 dark:border-blue-800/50">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-lg">
                    M
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">
                    Система активна
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Все службы работают
                  </p>
                </div>
                <div className="flex-shrink-0">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-lg shadow-green-500/50" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
