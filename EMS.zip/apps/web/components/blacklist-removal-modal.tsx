'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, UserX } from 'lucide-react';
import { toast } from 'sonner';

interface BlacklistRemovalModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function BlacklistRemovalModal({ open, onOpenChange }: BlacklistRemovalModalProps) {
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    static: '',
    discordId: '',
    blacklistReason: '',
    removalReason: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Валидация
    if (!formData.firstName || !formData.lastName || !formData.static || 
        !formData.discordId || !formData.blacklistReason || !formData.removalReason) {
      toast.error('Ошибка', {
        description: 'Пожалуйста, заполните все обязательные поля',
      });
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/applications/blacklist-removal', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit application');
      }

      toast.success('Успешно!', {
        description: 'Ваше заявление отправлено на рассмотрение',
      });

      // Очистка формы
      setFormData({
        firstName: '',
        lastName: '',
        static: '',
        discordId: '',
        blacklistReason: '',
        removalReason: '',
      });

      // Закрытие модального окна
      onOpenChange(false);
    } catch (error) {
      console.error('Error submitting application:', error);
      toast.error('Ошибка', {
        description: error instanceof Error ? error.message : 'Не удалось отправить заявление. Попробуйте позже.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-red-100 dark:bg-red-950/30">
              <UserX className="h-6 w-6 text-red-600 dark:text-red-400" />
            </div>
            <DialogTitle className="text-2xl">Заявление на вынесение из ЧС</DialogTitle>
          </div>
          <DialogDescription>
            Заполните все обязательные поля. Ваше заявление будет отправлено на рассмотрение.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">
                Имя <span className="text-red-500">*</span>
              </Label>
              <Input
                id="firstName"
                placeholder="Введите ваше имя"
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName">
                Фамилия <span className="text-red-500">*</span>
              </Label>
              <Input
                id="lastName"
                placeholder="Введите вашу фамилию"
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="static">
              Статик <span className="text-red-500">*</span>
            </Label>
            <Input
              id="static"
              placeholder="Введите ваш статик"
              value={formData.static}
              onChange={(e) => setFormData({ ...formData, static: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="discordId">
              Discord ID <span className="text-red-500">*</span>
            </Label>
            <Input
              id="discordId"
              placeholder="Например: 123456789012345678"
              value={formData.discordId}
              onChange={(e) => setFormData({ ...formData, discordId: e.target.value })}
              required
            />
            <p className="text-xs text-muted-foreground">
              Ваш числовой ID в Discord
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="blacklistReason">
              Причина занесения в ЧС <span className="text-red-500">*</span>
            </Label>
            <Textarea
              id="blacklistReason"
              placeholder="Опишите причину, по которой вы были занесены в чёрный список"
              value={formData.blacklistReason}
              onChange={(e) => setFormData({ ...formData, blacklistReason: e.target.value })}
              rows={3}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="removalReason">
              Причина для вынесения из ЧС <span className="text-red-500">*</span>
            </Label>
            <Textarea
              id="removalReason"
              placeholder="Объясните, почему вы должны быть вынесены из чёрного списка"
              value={formData.removalReason}
              onChange={(e) => setFormData({ ...formData, removalReason: e.target.value })}
              rows={4}
              required
            />
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Отмена
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Отправка...
                </>
              ) : (
                'Отправить заявление'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
