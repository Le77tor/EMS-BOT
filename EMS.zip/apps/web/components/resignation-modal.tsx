'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, CheckCircle2, AlertCircle, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

interface ResignationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Роли выговоров
const WARNING_ROLE_IDS = [
  '1482048390136070330', // Выговор 1
  '1482048390136070332', // Выговор 2
  '1482048390136070333', // Выговор 3
  '1482048390136070331', // Выговор 4
];

// Роль интернатуры
const INTERN_ROLE_ID = '1482048390136070326';

export function ResignationModal({ open, onOpenChange }: ResignationModalProps) {
  const { data: session, status } = useSession();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [reason, setReason] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [blacklistReason, setBlacklistReason] = useState<string>('');
  const [agreedToBlacklist, setAgreedToBlacklist] = useState(false);

  // Отладка: логируем статус сессии
  useEffect(() => {
    console.log('[resignation-modal] 🔐 Session status:', status);
    console.log('[resignation-modal] 👤 Session data:', session);
  }, [session, status]);

  // Проверка наличия ролей выговоров или интернатуры
  const checkBlacklistRoles = (): { hasBlacklist: boolean; reason: string } => {
    const userRoles = session?.user?.discordRoles;
    
    if (!Array.isArray(userRoles)) {
      return { hasBlacklist: false, reason: '' };
    }

    const userRoleIds = userRoles.map((role: any) => role.id);
    const hasWarnings = WARNING_ROLE_IDS.some(roleId => userRoleIds.includes(roleId));
    const hasIntern = userRoleIds.includes(INTERN_ROLE_ID);

    if (hasWarnings && hasIntern) {
      return { 
        hasBlacklist: true, 
        reason: 'У Вас есть активный выговор и не завершена интернатура! Если вы их не отработаете, вы будете уволены с ЧС, согласны ли вы с этим?' 
      };
    } else if (hasWarnings) {
      return { 
        hasBlacklist: true, 
        reason: 'У Вас есть активный выговор! Если вы его не отработаете, вы будете уволены с ЧС, согласны ли вы с этим?' 
      };
    } else if (hasIntern) {
      return { 
        hasBlacklist: true, 
        reason: 'Вы не прошли интернатуру, если она не будет пройдена, вы будете уволены с ЧС, согласны ли вы с этим?' 
      };
    }

    return { hasBlacklist: false, reason: '' };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Проверка авторизации
    if (status === 'loading') {
      toast.error('Подождите', {
        description: 'Проверяем авторизацию...',
      });
      return;
    }

    if (status === 'unauthenticated' || !session?.user) {
      toast.error('Требуется авторизация', {
        description: 'Пожалуйста, войдите в систему перед подачей заявления',
      });
      return;
    }
    
    // Валидация
    if (!reason || reason.trim().length < 10) {
      toast.error('Ошибка', {
        description: 'Пожалуйста, укажите причину увольнения (минимум 10 символов)',
      });
      return;
    }

    // Проверяем наличие выговоров или интернатуры
    const blacklistCheck = checkBlacklistRoles();
    if (blacklistCheck.hasBlacklist) {
      // Показываем модальное окно подтверждения
      setBlacklistReason(blacklistCheck.reason);
      setShowConfirmation(true);
      return;
    }

    // Если нет выговоров/интернатуры - сразу отправляем
    await submitResignation();
  };

  const submitResignation = async (agreed: boolean = false) => {
    setLoading(true);

    try {
      console.log('[resignation-modal] 📤 Submitting resignation application...', { reason, agreedToBlacklist: agreed });

      // Отправляем заявление
      const response = await fetch('/api/applications/resignation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          reason: reason.trim(),
          agreedToBlacklist: agreed, // Передаем флаг согласия с ЧС напрямую
        }),
      });

      const data = await response.json();

      console.log('[resignation-modal] 📥 Response:', { status: response.status, data });

      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit resignation application');
      }

      setSubmitted(true);

      toast.success('Заявление отправлено!', {
        description: data.message || 'Ваше заявление на увольнение отправлено. Ожидайте рассмотрения.',
        duration: 5000,
      });

      // Закрываем модальное окно через 3 секунды
      setTimeout(() => {
        onOpenChange(false);
        // Сбрасываем состояние
        setSubmitted(false);
        setReason('');
      }, 3000);
    } catch (error) {
      console.error('[resignation-modal] ❌ Error submitting resignation application:', error);
      toast.error('Ошибка', {
        description: error instanceof Error ? error.message : 'Не удалось отправить заявление. Попробуйте позже.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (!loading) {
      onOpenChange(false);
      setSubmitted(false);
      setReason('');
      setShowConfirmation(false);
      setBlacklistReason('');
      setAgreedToBlacklist(false);
    }
  };

  const handleConfirmBlacklist = async () => {
    setShowConfirmation(false);
    setAgreedToBlacklist(true); // Устанавливаем флаг согласия
    await submitResignation(true); // Передаем true напрямую
  };

  const handleCancelBlacklist = () => {
    setShowConfirmation(false);
    toast.info('Заявление отменено', {
      description: 'Вы отказались от увольнения с ЧС',
    });
    handleClose();
  };

  // Если не авторизован - показываем предупреждение
  if (status === 'unauthenticated') {
    return (
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <div className="flex items-center gap-2">
              <LogOut className="h-5 w-5" />
              <DialogTitle>Заявление на увольнение</DialogTitle>
            </div>
          </DialogHeader>

          <div className="flex flex-col items-center justify-center py-8 space-y-4">
            <AlertCircle className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-lg font-semibold">Требуется авторизация</h3>
            <p className="text-sm text-muted-foreground text-center">
              Для подачи заявления на увольнение необходимо войти в систему через Discord
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Модальное окно подтверждения ЧС
  if (showConfirmation) {
    return (
      <Dialog open={open} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              <DialogTitle>Подтверждение увольнения</DialogTitle>
            </div>
            <DialogDescription>
              Пожалуйста, подтвердите, что вы согласны с условиями увольнения
            </DialogDescription>
          </DialogHeader>

          <div className="rounded-lg border border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950 p-4">
            <div className="flex gap-3">
              <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-500 flex-shrink-0 mt-0.5" />
              <div className="space-y-2">
                <p className="text-sm font-medium text-red-900 dark:text-red-200">
                  Внимание!
                </p>
                <p className="text-sm text-red-800 dark:text-red-300">
                  {blacklistReason}
                </p>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleCancelBlacklist}
              disabled={loading}
            >
              Нет, отменить
            </Button>
            <Button 
              type="button" 
              onClick={handleConfirmBlacklist}
              disabled={loading}
              variant="destructive"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Отправка...
                </>
              ) : (
                'Да, согласен'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <LogOut className="h-5 w-5 text-red-500" />
            <DialogTitle>Заявление на увольнение</DialogTitle>
          </div>
          <DialogDescription>
            После одобрения заявления вы будете удалены с сервера. Пожалуйста, укажите причину увольнения.
          </DialogDescription>
        </DialogHeader>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Предупреждение */}
            <div className="rounded-lg border border-orange-200 bg-orange-50 dark:border-orange-900 dark:bg-orange-950 p-4">
              <div className="flex gap-3">
                <AlertTriangle className="h-5 w-5 text-orange-600 dark:text-orange-500 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium text-orange-900 dark:text-orange-200">
                    Важно!
                  </p>
                  <p className="text-sm text-orange-800 dark:text-orange-300">
                    После одобрения заявления на увольнение вы будете автоматически удалены с Discord сервера.
                    Если у вас есть активные выговоры или вы не прошли интернатуру, вы будете уволены с ЧС.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reason">
                Причина увольнения <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="reason"
                placeholder="Расскажите, почему вы хотите уволиться..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={6}
                required
                minLength={10}
                maxLength={1000}
              />
              <p className="text-xs text-muted-foreground">
                Минимум 10 символов, максимум 1000 символов
              </p>
            </div>

            {/* Индикатор статуса авторизации (только для отладки) */}
            {status === 'loading' && (
              <div className="text-sm text-muted-foreground">
                🔄 Проверка авторизации...
              </div>
            )}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                disabled={loading}
              >
                Отмена
              </Button>
              <Button 
                type="submit" 
                disabled={loading || status === 'loading'}
                variant="destructive"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Отправка...
                  </>
                ) : (
                  'Подать заявление'
                )}
              </Button>
            </DialogFooter>
          </form>
        ) : (
          <div className="flex flex-col items-center justify-center py-8">
            <CheckCircle2 className="h-16 w-16 text-green-500 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Заявление отправлено!</h3>
            <p className="text-sm text-muted-foreground text-center">
              Ваше заявление на увольнение успешно отправлено.<br />
              Ожидайте рассмотрения от руководства.
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
