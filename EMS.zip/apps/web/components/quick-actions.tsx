'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, Calendar, ArrowRightLeft, LogOut } from 'lucide-react';
import { VacationModal } from './vacation-modal';
import { ResignationModal } from './resignation-modal';
import { TransferModal } from './transfer-modal';

export function QuickActions() {
  const [vacationModalOpen, setVacationModalOpen] = useState(false);
  const [resignationModalOpen, setResignationModalOpen] = useState(false);
  const [transferModalOpen, setTransferModalOpen] = useState(false);
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">⚡ Быстрые действия</CardTitle>
        <CardDescription>
          Подайте заявку в один клик
        </CardDescription>
      </CardHeader>
      <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Система повышений */}
        <button
          onClick={() => alert('Функция "Система повышений" будет доступна позже')}
          className="group"
        >
          <Card className="border hover:border-blue-500/50 hover:bg-blue-500/5 transition-all cursor-pointer h-full">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0 p-2 rounded-lg bg-blue-500/10">
                  <TrendingUp className="h-5 w-5 text-blue-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">
                    Система повышений
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Подать заявление
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </button>

        {/* Отпуск */}
        <button
          onClick={() => setVacationModalOpen(true)}
          className="group"
        >
          <Card className="border hover:border-green-500/50 hover:bg-green-500/5 transition-all cursor-pointer h-full">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0 p-2 rounded-lg bg-green-500/10">
                  <Calendar className="h-5 w-5 text-green-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">
                    Отпуск
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Подать заявление
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </button>

        {/* Перевод в отдел */}
        <button
          onClick={() => setTransferModalOpen(true)}
          className="group"
        >
          <Card className="border hover:border-purple-500/50 hover:bg-purple-500/5 transition-all cursor-pointer h-full">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0 p-2 rounded-lg bg-purple-500/10">
                  <ArrowRightLeft className="h-5 w-5 text-purple-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">
                    Перевод в отдел
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Подать заявление
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </button>

        {/* Заявление на увольнение */}
        <button
          onClick={() => setResignationModalOpen(true)}
          className="group"
        >
          <Card className="border hover:border-red-500/50 hover:bg-red-500/5 transition-all cursor-pointer h-full">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0 p-2 rounded-lg bg-red-500/10">
                  <LogOut className="h-5 w-5 text-red-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">
                    Увольнение
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Подать заявление
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </button>
      </CardContent>
      
      {/* Модальное окно отпуска */}
      <VacationModal 
        open={vacationModalOpen} 
        onOpenChange={setVacationModalOpen} 
      />
      
      {/* Модальное окно перевода */}
      <TransferModal 
        open={transferModalOpen} 
        onOpenChange={setTransferModalOpen} 
      />
      
      {/* Модальное окно увольнения */}
      <ResignationModal 
        open={resignationModalOpen} 
        onOpenChange={setResignationModalOpen} 
      />
    </Card>
  );
}
