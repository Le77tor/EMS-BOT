'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';
import { CalendarIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Loader2, Calendar as CalendarIconLucide, CheckCircle2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface VacationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function VacationModal({ open, onOpenChange }: VacationModalProps) {
  const { data: session, status } = useSession();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  const [formData, setFormData] = useState({
    vacationType: '', // 'OOC' или 'IC'
    startDate: undefined as Date | undefined,
    endDate: undefined as Date | undefined,
    reason: '',
  });

  // Отладка: логируем статус сессии
  useEffect(() => {
    console.log('[vacation-modal] 🔐 Session status:', status);
    console.log('[vacation-modal] 👤 Session data:', session);
  }, [session, status]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Проверка авторизации
    if (status === 'loading') {
      toast.error('Подождите', {
        description: 'Проверяем авторизацию...',
      });
      return;
    }

    if (status === 'unauthenticated' || !session?.user) {
      toast.error('Требуется авторизация', {
        description: 'Пожалуйста, войдите в систему перед подачей заявки',
      });
      return;
    }
    
    // Валидация
    if (!formData.vacationType || !formData.startDate || !formData.endDate || !formData.reason) {
      toast.error('Ошибка', {
        description: 'Пожалуйста, заполните все обязательные поля',
      });
      return;
    }

    // Проверка дат
    const start = formData.startDate;
    const end = formData.endDate;
    
    if (end < start) {
      toast.error('Ошибка', {
        description: 'Дата окончания не может быть раньше даты начала',
      });
      return;
    }

    setLoading(true);

    try {
      console.log('[vacation-modal] 📤 Submitting vacation application...', formData);

      // Отправляем заявку
      const response = await fetch('/api/applications/vacation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vacationType: formData.vacationType,
          startDate: format(formData.startDate, 'yyyy-MM-dd'),
          endDate: format(formData.endDate, 'yyyy-MM-dd'),
          reason: formData.reason,
        }),
      });

      const data = await response.json();

      console.log('[vacation-modal] 📥 Response:', { status: response.status, data });

      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit vacation application');
      }

      setSubmitted(true);

      toast.success('Успешно!', {
        description: 'Ваше заявление на отпуск отправлено. Ожидайте рассмотрения.',
        duration: 5000,
      });

      // Закрываем модальное окно через 3 секунды
      setTimeout(() => {
        onOpenChange(false);
        // Сбрасываем состояние
        setSubmitted(false);
        setFormData({
          vacationType: '',
          startDate: undefined,
          endDate: undefined,
          reason: '',
        });
      }, 3000);
    } catch (error) {
      console.error('[vacation-modal] ❌ Error submitting vacation application:', error);
      toast.error('Ошибка', {
        description: error instanceof Error ? error.message : 'Не удалось отправить заявление. Попробуйте позже.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (!loading) {
      onOpenChange(false);
      setSubmitted(false);
      setFormData({
        vacationType: '',
        startDate: undefined,
        endDate: undefined,
        reason: '',
      });
    }
  };

  // Если не авторизован - показываем предупреждение
  if (status === 'unauthenticated') {
    return (
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              <DialogTitle>Заявление на отпуск</DialogTitle>
            </div>
          </DialogHeader>

          <div className="flex flex-col items-center justify-center py-8 space-y-4">
            <AlertCircle className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-lg font-semibold">Требуется авторизация</h3>
            <p className="text-sm text-muted-foreground text-center">
              Для подачи заявления на отпуск необходимо войти в систему через Discord
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <CalendarIconLucide className="h-5 w-5" />
            <DialogTitle>Заявление на отпуск</DialogTitle>
          </div>
          <DialogDescription>
            Заполните все обязательные поля. После одобрения вам будут автоматически выданы роли отпуска.
          </DialogDescription>
        </DialogHeader>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="vacationType">
                Тип отпуска <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.vacationType}
                onValueChange={(value) => setFormData({ ...formData, vacationType: value })}
              >
                <SelectTrigger id="vacationType">
                  <SelectValue placeholder="Выберите тип отпуска" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="OOC">OOC (Out of Character)</SelectItem>
                  <SelectItem value="IC">IC (In Character)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                OOC - реальные причины, IC - игровые причины
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">
                  Дата начала <span className="text-red-500">*</span>
                </Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      id="startDate"
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !formData.startDate && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.startDate ? (
                        format(formData.startDate, 'dd MMMM yyyy', { locale: ru })
                      ) : (
                        <span>Выберите дату</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formData.startDate}
                      onSelect={(date) => setFormData({ ...formData, startDate: date })}
                      initialFocus
                      locale={ru}
                      disabled={(date) => {
                        const tomorrow = new Date();
                        tomorrow.setDate(tomorrow.getDate() + 1);
                        tomorrow.setHours(0, 0, 0, 0);
                        return date < tomorrow;
                      }}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="endDate">
                  Дата окончания <span className="text-red-500">*</span>
                </Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      id="endDate"
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !formData.endDate && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formData.endDate ? (
                        format(formData.endDate, 'dd MMMM yyyy', { locale: ru })
                      ) : (
                        <span>Выберите дату</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formData.endDate}
                      onSelect={(date) => setFormData({ ...formData, endDate: date })}
                      initialFocus
                      locale={ru}
                      disabled={(date) => formData.startDate ? date < formData.startDate : false}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reason">
                Причина отпуска <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="reason"
                placeholder="Расскажите, почему вам нужен отпуск..."
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                rows={4}
                required
              />
            </div>

            {/* Индикатор статуса авторизации (только для отладки) */}
            {status === 'loading' && (
              <div className="text-sm text-muted-foreground">
                🔄 Проверка авторизации...
              </div>
            )}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                disabled={loading}
              >
                Отмена
              </Button>
              <Button type="submit" disabled={loading || status === 'loading'}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Отправка...
                  </>
                ) : (
                  'Отправить заявление'
                )}
              </Button>
            </DialogFooter>
          </form>
        ) : (
          <div className="flex flex-col items-center justify-center py-8">
            <CheckCircle2 className="h-16 w-16 text-green-500 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Заявление отправлено!</h3>
            <p className="text-sm text-muted-foreground text-center">
              Ваше заявление на отпуск успешно отправлено.<br />
              Ожидайте одобрения от руководства. После одобрения роли будут выданы автоматически.
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
