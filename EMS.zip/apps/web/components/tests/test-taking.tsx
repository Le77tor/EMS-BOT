'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Clock, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface TestTakingProps {
  test: {
    id: string;
    title: string;
    description: string | null;
    passingScore: number;
    timeLimit: number | null;
    questionsPerAttempt: number | null;
    shuffleQuestions: boolean;
    shuffleAnswers: boolean;
    questions: {
      id: string;
      question: string;
      type: string;
      options: any;
      order: number;
    }[];
  };
  userId: string;
}

function shuffleArray<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function TestTaking({ test, userId }: TestTakingProps) {
  const router = useRouter();
  const [started, setStarted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number[]>>({});
  const [timeRemaining, setTimeRemaining] = useState(
    test.timeLimit ? test.timeLimit * 60 : null
  );

  // Подготовка вопросов
  const [displayQuestions, setDisplayQuestions] = useState<typeof test.questions>([]);

  useEffect(() => {
    if (!started) return;

    let questions = [...test.questions];

    // Ограничиваем количество вопросов если нужно
    if (test.questionsPerAttempt && test.questionsPerAttempt < questions.length) {
      questions = shuffleArray(questions).slice(0, test.questionsPerAttempt);
    }

    // Перемешиваем вопросы если нужно
    if (test.shuffleQuestions) {
      questions = shuffleArray(questions);
    }

    // Перемешиваем варианты ответов если нужно
    if (test.shuffleAnswers) {
      questions = questions.map((q) => ({
        ...q,
        options: JSON.stringify(shuffleArray(JSON.parse(q.options))),
      }));
    }

    setDisplayQuestions(questions);
  }, [started]);

  // Таймер
  useEffect(() => {
    if (!started || timeRemaining === null) return;

    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev === null || prev <= 1) {
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [started, timeRemaining]);

  const handleStart = () => {
    setStarted(true);
  };

  const currentQuestion = displayQuestions[currentQuestionIndex];
  const currentAnswers = currentQuestion ? answers[currentQuestion.id] || [] : [];

  const handleAnswerChange = (optionIndex: number) => {
    if (!currentQuestion) return;

    const questionType = currentQuestion.type;
    const currentAnswers = answers[currentQuestion.id] || [];

    if (questionType === 'MULTIPLE_CHOICE') {
      // Один правильный ответ - заменяем
      setAnswers({
        ...answers,
        [currentQuestion.id]: [optionIndex],
      });
    } else {
      // Несколько правильных ответов - переключаем
      const newAnswers = currentAnswers.includes(optionIndex)
        ? currentAnswers.filter((i) => i !== optionIndex)
        : [...currentAnswers, optionIndex];
      setAnswers({
        ...answers,
        [currentQuestion.id]: newAnswers,
      });
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < displayQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleSubmit = async () => {
    setSubmitting(true);

    try {
      const response = await fetch('/api/tests/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          testId: test.id,
          answers: displayQuestions.map((q) => ({
            questionId: q.id,
            selectedOptions: answers[q.id] || [],
          })),
        }),
      });

      if (!response.ok) throw new Error('Ошибка отправки');

      const result = await response.json();
      router.push(`/test/${test.id}/result/${result.attemptId}`);
    } catch (error) {
      console.error('Ошибка:', error);
      alert('Ошибка при отправке теста');
      setSubmitting(false);
    }
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const answeredCount = Object.keys(answers).length;
  const progress = displayQuestions.length > 0
    ? (answeredCount / displayQuestions.length) * 100
    : 0;

  // Стартовая страница
  if (!started) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-2xl w-full">
          <CardHeader>
            <CardTitle className="text-2xl">{test.title}</CardTitle>
            <CardDescription>{test.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Вопросов</p>
                <p className="text-2xl font-bold">
                  {test.questionsPerAttempt || test.questions.length}
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Время на тест</p>
                <p className="text-2xl font-bold">
                  {test.timeLimit ? `${test.timeLimit} мин` : 'Без ограничений'}
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Проходной балл</p>
                <p className="text-2xl font-bold">от {test.passingScore}%</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Тип</p>
                <div className="flex gap-2 flex-wrap">
                  {test.shuffleQuestions && (
                    <Badge variant="outline" className="text-xs">
                      Вопросы перемешаны
                    </Badge>
                  )}
                  {test.shuffleAnswers && (
                    <Badge variant="outline" className="text-xs">
                      Ответы миксуются
                    </Badge>
                  )}
                </div>
              </div>
            </div>

            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-semibold text-sm">Важно:</p>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• После начала теста нельзя закрывать страницу</li>
                    {test.timeLimit && (
                      <li>• При истечении времени тест будет отправлен автоматически</li>
                    )}
                    <li>• Вы можете вернуться к предыдущим вопросам</li>
                  </ul>
                </div>
              </div>
            </div>

            <Button onClick={handleStart} className="w-full" size="lg">
              Начать тест
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Прохождение теста
  if (displayQuestions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Загрузка вопросов...</p>
      </div>
    );
  }

  const options = currentQuestion ? JSON.parse(currentQuestion.options) : [];

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header с таймером */}
        <Card>
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-semibold">{test.title}</h2>
                <p className="text-sm text-muted-foreground">
                  Вопрос {currentQuestionIndex + 1} из {displayQuestions.length}
                </p>
              </div>
              {timeRemaining !== null && (
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-orange-500" />
                  <span
                    className={`text-xl font-bold ${
                      timeRemaining < 60 ? 'text-red-500' : 'text-foreground'
                    }`}
                  >
                    {formatTime(timeRemaining)}
                  </span>
                </div>
              )}
            </div>
            <Progress value={progress} className="mt-4" />
          </CardContent>
        </Card>

        {/* Вопрос */}
        <Card>
          <CardHeader>
            <div className="flex items-start gap-4">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary font-bold flex-shrink-0">
                {currentQuestionIndex + 1}
              </div>
              <div className="flex-1">
                <CardTitle className="text-xl mb-2">
                  {currentQuestion?.question}
                </CardTitle>
                <CardDescription>
                  {currentQuestion?.type === 'MULTIPLE_CHOICE'
                    ? 'Выберите один правильный ответ'
                    : 'Выберите все правильные ответы'}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {options.map((option: any, index: number) => {
              const isSelected = currentAnswers.includes(index);
              const inputType =
                currentQuestion?.type === 'MULTIPLE_CHOICE' ? 'radio' : 'checkbox';

              return (
                <label
                  key={index}
                  className={`flex items-start gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    isSelected
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <input
                    type={inputType}
                    checked={isSelected}
                    onChange={() => handleAnswerChange(index)}
                    className="mt-1"
                  />
                  <span className="flex-1">{option.text}</span>
                </label>
              );
            })}
          </CardContent>
        </Card>

        {/* Навигация */}
        <div className="flex items-center justify-between gap-4">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestionIndex === 0}
          >
            Назад
          </Button>

          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              Отвечено: {answeredCount} из {displayQuestions.length}
            </span>
          </div>

          {currentQuestionIndex < displayQuestions.length - 1 ? (
            <Button onClick={handleNext} className="gap-2">
              Далее
              <ArrowRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="gap-2"
            >
              {submitting ? 'Отправка...' : 'Завершить тест'}
              <CheckCircle2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
