'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, GripVertical, ChevronDown } from 'lucide-react';
import { useRouter } from 'next/navigation';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface Question {
  id: string;
  question: string;
  type: 'MULTIPLE_CHOICE' | 'MULTIPLE_SELECT';
  options: { text: string; isCorrect: boolean }[];
  explanation: string;
}

const DEPARTMENTS = [
  { id: 'all', name: 'Все EMS' },
  { id: '1482048390119555125', name: 'High Staff' },
  { id: '1482048390148784230', name: 'HAD' },
  { id: '1482048390148784231', name: 'PSED' },
  { id: '1550899527450632362', name: 'DI' },
  { id: '1482048390148784232', name: 'DES' },
  { id: '1482048390148784233', name: 'PM' },
  { id: '1551243488006250628', name: 'Intern' },
];

export function TestEditor() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  
  // Основные настройки
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [accessRole, setAccessRole] = useState('all');
  
  // Настройки прохождения
  const [passingScore, setPassingScore] = useState(70);
  const [timeLimit, setTimeLimit] = useState(15);
  const [questionsPerAttempt, setQuestionsPerAttempt] = useState(25);
  const [retryDelay, setRetryDelay] = useState(1440); // 24 часа в минутах
  
  // Настройки отображения
  const [shuffleQuestions, setShuffleQuestions] = useState(false);
  const [shuffleAnswers, setShuffleAnswers] = useState(false);
  const [showReview, setShowReview] = useState(false);
  
  // Вопросы
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: '1',
      question: '',
      type: 'MULTIPLE_CHOICE',
      options: [
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
      ],
      explanation: '',
    },
  ]);

  const addQuestion = () => {
    setQuestions([
      ...questions,
      {
        id: Date.now().toString(),
        question: '',
        type: 'MULTIPLE_CHOICE',
        options: [
          { text: '', isCorrect: false },
          { text: '', isCorrect: false },
        ],
        explanation: '',
      },
    ]);
  };

  const removeQuestion = (id: string) => {
    setQuestions(questions.filter((q) => q.id !== id));
  };

  const updateQuestion = (id: string, field: string, value: any) => {
    setQuestions(
      questions.map((q) =>
        q.id === id ? { ...q, [field]: value } : q
      )
    );
  };

  const addOption = (questionId: string) => {
    setQuestions(
      questions.map((q) =>
        q.id === questionId
          ? {
              ...q,
              options: [...q.options, { text: '', isCorrect: false }],
            }
          : q
      )
    );
  };

  const removeOption = (questionId: string, optionIndex: number) => {
    setQuestions(
      questions.map((q) =>
        q.id === questionId
          ? {
              ...q,
              options: q.options.filter((_, i) => i !== optionIndex),
            }
          : q
      )
    );
  };

  const updateOption = (
    questionId: string,
    optionIndex: number,
    field: 'text' | 'isCorrect',
    value: string | boolean
  ) => {
    setQuestions(
      questions.map((q) =>
        q.id === questionId
          ? {
              ...q,
              options: q.options.map((opt, i) =>
                i === optionIndex ? { ...opt, [field]: value } : opt
              ),
            }
          : q
      )
    );
  };

  const toggleCorrectAnswer = (questionId: string, optionIndex: number) => {
    setQuestions(
      questions.map((q) => {
        if (q.id !== questionId) return q;

        // Для MULTIPLE_CHOICE — только один правильный ответ
        if (q.type === 'MULTIPLE_CHOICE') {
          return {
            ...q,
            options: q.options.map((opt, i) => ({
              ...opt,
              isCorrect: i === optionIndex,
            })),
          };
        }

        // Для MULTIPLE_SELECT — можно несколько
        return {
          ...q,
          options: q.options.map((opt, i) =>
            i === optionIndex ? { ...opt, isCorrect: !opt.isCorrect } : opt
          ),
        };
      })
    );
  };

  const handleSave = async (status: 'DRAFT' | 'PUBLISHED') => {
    setSaving(true);

    try {
      const response = await fetch('/api/tests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description,
          status,
          accessRoles: accessRole === 'all' ? null : [accessRole],
          passingScore,
          timeLimit,
          questionsPerAttempt,
          retryDelay,
          shuffleQuestions,
          shuffleAnswers,
          showReview,
          questions: questions.map((q, index) => ({
            question: q.question,
            type: q.type,
            options: q.options,
            explanation: q.explanation,
            order: index,
          })),
        }),
      });

      if (!response.ok) throw new Error('Ошибка сохранения');

      const data = await response.json();
      router.push('/dashboard/tests');
    } catch (error) {
      console.error('Ошибка:', error);
      alert('Ошибка при сохранении теста');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Основная информация */}
      <Card>
        <CardHeader>
          <CardTitle>Основная информация</CardTitle>
          <CardDescription>
            Название теста и кому он предназначен
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">Название</Label>
              <Input
                id="title"
                placeholder="Например: Переаттестация EMS"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="access">Доступ</Label>
              <Select value={accessRole} onValueChange={setAccessRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DEPARTMENTS.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Описание</Label>
            <Textarea
              id="description"
              placeholder="Что проверяет тест и кому он предназначен"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Настройки прохождения */}
      <Card>
        <CardHeader>
          <CardTitle>Настройки прохождения</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="passingScore">Проходной процент</Label>
              <Input
                id="passingScore"
                type="number"
                min="0"
                max="100"
                value={passingScore}
                onChange={(e) => setPassingScore(Number(e.target.value))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="timeLimit">Время, минут</Label>
              <Input
                id="timeLimit"
                type="number"
                min="1"
                value={timeLimit}
                onChange={(e) => setTimeLimit(Number(e.target.value))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="questionsPerAttempt">Вопросов в попытке</Label>
              <Input
                id="questionsPerAttempt"
                type="number"
                min="1"
                value={questionsPerAttempt}
                onChange={(e) => setQuestionsPerAttempt(Number(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                Из общего банка случайно выбирается указанное количество
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="retryDelay">Пауза между попытками, минут</Label>
              <Input
                id="retryDelay"
                type="number"
                min="0"
                value={retryDelay}
                onChange={(e) => setRetryDelay(Number(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                0 — повтор сразу, текущее значение: {Math.floor(retryDelay / 60)} ч {retryDelay % 60} мин
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Переключатели */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label htmlFor="shuffleQuestions" className="font-semibold">
                  Перемешивать вопросы
                </Label>
                <p className="text-xs text-muted-foreground">
                  Новый порядок для каждой попытки
                </p>
              </div>
              <Switch
                id="shuffleQuestions"
                checked={shuffleQuestions}
                onCheckedChange={setShuffleQuestions}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label htmlFor="shuffleAnswers" className="font-semibold">
                  Миксовать ответы
                </Label>
                <p className="text-xs text-muted-foreground">
                  Варианты меняют порядок
                </p>
              </div>
              <Switch
                id="shuffleAnswers"
                checked={shuffleAnswers}
                onCheckedChange={setShuffleAnswers}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label htmlFor="showReview" className="font-semibold">
                  Показывать разбор
                </Label>
                <p className="text-xs text-muted-foreground">
                  После завершения теста
                </p>
              </div>
              <Switch
                id="showReview"
                checked={showReview}
                onCheckedChange={setShowReview}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Конструктор вопросов */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Вопросы · {questions.length}</CardTitle>
              <CardDescription>КОНСТРУКТОР</CardDescription>
            </div>
            <Button onClick={addQuestion} variant="outline" className="gap-2">
              <Plus className="h-4 w-4" />
              Добавить вопрос
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {questions.map((question, qIndex) => (
            <Card key={question.id} className="border-2">
              <CardHeader className="pb-4">
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary font-bold flex-shrink-0">
                    {qIndex + 1}
                  </div>
                  <div className="flex-1 space-y-3">
                    <Textarea
                      placeholder="Текст вопроса"
                      value={question.question}
                      onChange={(e) =>
                        updateQuestion(question.id, 'question', e.target.value)
                      }
                      rows={2}
                    />

                    <div className="flex items-center gap-4">
                      <Select
                        value={question.type}
                        onValueChange={(value) =>
                          updateQuestion(question.id, 'type', value)
                        }
                      >
                        <SelectTrigger className="w-[200px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="MULTIPLE_CHOICE">
                            Один ответ
                          </SelectItem>
                          <SelectItem value="MULTIPLE_SELECT">
                            Несколько ответов
                          </SelectItem>
                        </SelectContent>
                      </Select>

                      <Input
                        type="number"
                        min="1"
                        className="w-20"
                        value={question.options.length}
                        disabled
                      />

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeQuestion(question.id)}
                        className="ml-auto text-red-500 hover:text-red-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-3">
                <div className="text-sm text-muted-foreground mb-2">
                  {question.type === 'MULTIPLE_CHOICE'
                    ? 'Отметьте один правильный ответ'
                    : 'Отметьте все правильные ответы'}
                </div>

                {question.options.map((option, oIndex) => (
                  <div key={oIndex} className="flex items-center gap-3">
                    <input
                      type={
                        question.type === 'MULTIPLE_CHOICE'
                          ? 'radio'
                          : 'checkbox'
                      }
                      checked={option.isCorrect}
                      onChange={() =>
                        toggleCorrectAnswer(question.id, oIndex)
                      }
                      className="w-5 h-5 flex-shrink-0"
                    />
                    <Input
                      placeholder={`Вариант ${oIndex + 1}`}
                      value={option.text}
                      onChange={(e) =>
                        updateOption(
                          question.id,
                          oIndex,
                          'text',
                          e.target.value
                        )
                      }
                      className="flex-1"
                    />
                    {question.options.length > 2 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeOption(question.id, oIndex)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => addOption(question.id)}
                  className="w-full"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Вариант ответа
                </Button>

                <div className="pt-2">
                  <Label className="text-xs text-muted-foreground">
                    Разбор после ответа - необязательно
                  </Label>
                  <Textarea
                    placeholder="Почему этот ответ правильный"
                    value={question.explanation}
                    onChange={(e) =>
                      updateQuestion(question.id, 'explanation', e.target.value)
                    }
                    rows={2}
                    className="mt-2"
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      {/* Действия */}
      <div className="flex items-center justify-between gap-4 pt-4">
        <Button
          variant="outline"
          onClick={() => router.back()}
          disabled={saving}
        >
          Отмена
        </Button>
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => handleSave('DRAFT')}
            disabled={saving}
          >
            Черновик
          </Button>
          <Button onClick={() => handleSave('PUBLISHED')} disabled={saving}>
            Опубликовать
          </Button>
        </div>
      </div>
    </div>
  );
}
