'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, Trophy, Clock, Target, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

interface TestResultProps {
  attempt: {
    id: string;
    score: number;
    passed: boolean;
    correctAnswers: number;
    totalQuestions: number;
    answers: any;
    completedAt: Date | null;
    test: {
      id: string;
      title: string;
      description: string | null;
      passingScore: number;
      showReview: boolean;
      questions: {
        id: string;
        question: string;
        type: string;
        options: any;
        explanation: string | null;
        order: number;
      }[];
    };
    user: {
      username: string;
      displayName: string | null;
      discordId: string;
      avatar: string | null;
    };
  };
  canSeeDetails: boolean;
  isOwner: boolean;
}

export function TestResult({ attempt, canSeeDetails, isOwner }: TestResultProps) {
  const answers = typeof attempt.answers === 'string' 
    ? JSON.parse(attempt.answers) 
    : attempt.answers;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Результат */}
        <Card className={attempt.passed ? 'border-green-500/50' : 'border-red-500/50'}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {attempt.passed ? (
                  <div className="p-3 rounded-full bg-green-500/10">
                    <Trophy className="h-8 w-8 text-green-500" />
                  </div>
                ) : (
                  <div className="p-3 rounded-full bg-red-500/10">
                    <XCircle className="h-8 w-8 text-red-500" />
                  </div>
                )}
                <div>
                  <CardTitle className="text-2xl">
                    {attempt.passed ? 'Успешная сдача!' : 'Не сдано'}
                  </CardTitle>
                  <CardDescription>
                    {attempt.test.title}
                  </CardDescription>
                </div>
              </div>
              <Badge
                variant={attempt.passed ? 'default' : 'destructive'}
                className="text-2xl px-4 py-2"
              >
                {attempt.score.toFixed(1)}%
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Target className="h-4 w-4" />
                  <span>Правильных ответов</span>
                </div>
                <p className="text-3xl font-bold">
                  {attempt.correctAnswers} / {attempt.totalQuestions}
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Trophy className="h-4 w-4" />
                  <span>Проходной балл</span>
                </div>
                <p className="text-3xl font-bold">{attempt.test.passingScore}%</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>Завершено</span>
                </div>
                <p className="text-lg font-semibold">
                  {attempt.completedAt
                    ? new Date(attempt.completedAt).toLocaleString('ru-RU')
                    : 'Неизвестно'}
                </p>
              </div>
            </div>

            {!attempt.passed && (
              <div className="mt-6 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  Вы набрали <strong>{attempt.score.toFixed(1)}%</strong>, но для прохождения требуется минимум{' '}
                  <strong>{attempt.test.passingScore}%</strong>. Попробуйте ещё раз.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Пользователь (если не владелец) */}
        {!isOwner && (
          <Card>
            <CardHeader>
              <CardTitle>Пользователь</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3">
                {attempt.user.avatar && attempt.user.discordId ? (
                  <img
                    src={`https://cdn.discordapp.com/avatars/${attempt.user.discordId}/${attempt.user.avatar}.png`}
                    alt={attempt.user.username}
                    className="w-12 h-12 rounded-full"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                    {attempt.user.username.charAt(0).toUpperCase()}
                  </div>
                )}
                <div>
                  <p className="font-semibold">
                    {attempt.user.displayName || attempt.user.username}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {attempt.user.username}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Разбор ответов (только если есть доступ) */}
        {canSeeDetails ? (
          <Card>
            <CardHeader>
              <CardTitle>Разбор ответов</CardTitle>
              <CardDescription>
                Детальный анализ каждого вопроса
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {answers.map((answer: any, index: number) => {
                const question = attempt.test.questions.find(
                  (q) => q.id === answer.questionId
                );
                if (!question) return null;

                const options = JSON.parse(question.options);
                const correctOptions = options
                  .map((opt: any, i: number) => (opt.isCorrect ? i : -1))
                  .filter((i: number) => i !== -1);
                const userAnswers = answer.selectedOptions || [];

                const isCorrect =
                  correctOptions.length === userAnswers.length &&
                  correctOptions.every((val: number) => userAnswers.includes(val));

                return (
                  <div
                    key={answer.questionId}
                    className={`p-6 rounded-lg border-2 ${
                      isCorrect
                        ? 'border-green-500/30 bg-green-500/5'
                        : 'border-red-500/30 bg-red-500/5'
                    }`}
                  >
                    <div className="flex items-start gap-4 mb-4">
                      <div
                        className={`flex items-center justify-center w-10 h-10 rounded-full flex-shrink-0 ${
                          isCorrect
                            ? 'bg-green-500/20 text-green-500'
                            : 'bg-red-500/20 text-red-500'
                        }`}
                      >
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between gap-4">
                          <p className="font-semibold text-lg">
                            {question.question}
                          </p>
                          {isCorrect ? (
                            <CheckCircle2 className="h-6 w-6 text-green-500 flex-shrink-0" />
                          ) : (
                            <XCircle className="h-6 w-6 text-red-500 flex-shrink-0" />
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 ml-14">
                      {options.map((option: any, optIndex: number) => {
                        const isUserSelected = userAnswers.includes(optIndex);
                        const isCorrectOption = option.isCorrect;

                        let className = 'p-3 rounded-lg border ';
                        if (isCorrectOption && isUserSelected) {
                          className += 'border-green-500 bg-green-500/10';
                        } else if (isCorrectOption && !isUserSelected) {
                          className += 'border-green-500/50 bg-green-500/5';
                        } else if (!isCorrectOption && isUserSelected) {
                          className += 'border-red-500 bg-red-500/10';
                        } else {
                          className += 'border-border';
                        }

                        return (
                          <div key={optIndex} className={className}>
                            <div className="flex items-center gap-3">
                              {isUserSelected && (
                                <div className="flex-shrink-0">
                                  {isCorrectOption ? (
                                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                                  ) : (
                                    <XCircle className="h-5 w-5 text-red-500" />
                                  )}
                                </div>
                              )}
                              {!isUserSelected && isCorrectOption && (
                                <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0" />
                              )}
                              <span className="flex-1">{option.text}</span>
                              {isUserSelected && (
                                <Badge variant="outline" className="text-xs">
                                  Ваш ответ
                                </Badge>
                              )}
                              {isCorrectOption && !isUserSelected && (
                                <Badge variant="outline" className="text-xs bg-green-500/10 text-green-500">
                                  Правильный
                                </Badge>
                              )}
                            </div>
                          </div>
                        );
                      })}

                      {question.explanation && (
                        <div className="mt-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                          <p className="text-sm font-semibold mb-2 text-blue-400">
                            Пояснение:
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {question.explanation}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">
                Детальный разбор ответов доступен только для кураторов и руководства
              </p>
            </CardContent>
          </Card>
        )}

        {/* Действия */}
        <div className="flex items-center justify-between gap-4">
          <Link href="/dashboard/tests">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              К списку тестов
            </Button>
          </Link>

          {isOwner && !attempt.passed && (
            <Link href={`/test/${attempt.test.id}`}>
              <Button className="gap-2">
                Попробовать снова
              </Button>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
