'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, Edit, Link as LinkIcon, Clock, FileQuestion } from 'lucide-react';
import Link from 'next/link';

interface TestCardProps {
  test: {
    id: string;
    title: string;
    description: string | null;
    status: string;
    passingScore: number;
    timeLimit: number | null;
    questionsPerAttempt: number | null;
    retryDelay: number;
    questions: { id: string }[];
    attempts: { id: string; passed: boolean }[];
    creator: {
      username: string;
      displayName: string | null;
    };
  };
  canEdit: boolean;
}

export function TestCard({ test, canEdit }: TestCardProps) {
  const totalQuestions = test.questions.length;
  const totalAttempts = test.attempts.length;
  const passedAttempts = test.attempts.filter(a => a.passed).length;
  const passRate = totalAttempts > 0 ? Math.round((passedAttempts / totalAttempts) * 100) : 0;

  const isPublished = test.status === 'PUBLISHED';

  return (
    <Card className="hover:border-primary/50 transition-all">
      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant={isPublished ? 'default' : 'secondary'}>
                {isPublished ? 'Опубликован' : 'Черновик'}
              </Badge>
              {test.questionsPerAttempt && test.questionsPerAttempt < totalQuestions && (
                <Badge variant="outline" className="text-xs">
                  {test.questionsPerAttempt} из {totalQuestions} вопросов
                </Badge>
              )}
            </div>
            <CardTitle className="text-lg">{test.title}</CardTitle>
            <CardDescription className="mt-1 line-clamp-2">
              {test.description || 'Без описания'}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <FileQuestion className="h-4 w-4" />
              <span>Вопросов</span>
            </div>
            <p className="text-2xl font-bold">{totalQuestions}</p>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>Время</span>
            </div>
            <p className="text-2xl font-bold">
              {test.timeLimit ? `${test.timeLimit} мин` : '∞'}
            </p>
          </div>
        </div>

        {/* Pass info */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Проходной балл</span>
            <span className="font-semibold">от {test.passingScore}%</span>
          </div>
          
          {totalAttempts > 0 && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Успешно сдано</span>
              <span className="font-semibold">{passRate}%</span>
            </div>
          )}

          {test.retryDelay > 0 && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Повтор через</span>
              <span className="font-semibold">{test.retryDelay} мин</span>
            </div>
          )}
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400 border-blue-500/20">
            Все EMS
          </Badge>
          <Badge variant="outline" className="text-xs bg-purple-500/10 text-purple-400 border-purple-500/20">
            {totalAttempts} {totalAttempts === 1 ? 'прохождение' : 'прохождений'}
          </Badge>
          {test.timeLimit && (
            <Badge variant="outline" className="text-xs bg-orange-500/10 text-orange-400 border-orange-500/20">
              {test.timeLimit} мин
            </Badge>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          {isPublished && (
            <Link href={`/test/${test.id}`} className="flex-1">
              <Button className="w-full gap-2" size="sm">
                <Play className="h-4 w-4" />
                Открыть
              </Button>
            </Link>
          )}
          
          {canEdit && (
            <>
              <Link href={`/dashboard/tests/${test.id}/edit`}>
                <Button variant="outline" size="sm" className="gap-2">
                  <Edit className="h-4 w-4" />
                  Изменить
                </Button>
              </Link>
              
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  const url = `${window.location.origin}/test/${test.id}`;
                  navigator.clipboard.writeText(url);
                  alert('Ссылка скопирована!');
                }}
              >
                <LinkIcon className="h-4 w-4" />
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
