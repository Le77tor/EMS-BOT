'use client';

import { useState, useEffect } from 'react';
import { useSession, signIn } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Briefcase, CheckCircle2, LogIn } from 'lucide-react';
import { toast } from 'sonner';

interface EmploymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function EmploymentModal({ open, onOpenChange }: EmploymentModalProps) {
  const { data: session, status } = useSession();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    static: '',
    reason: '',
  });

  // Отладка: логируем статус сессии
  useEffect(() => {
    console.log('🔐 Session status:', status);
    console.log('👤 Session data:', session);
  }, [session, status]);

  // Автоматически открываем модалку после успешной авторизации
  useEffect(() => {
    // Проверяем URL параметры - если есть ?employment=true, значит вернулись после авторизации
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const shouldOpen = params.get('employment');
      
      if (shouldOpen === 'true' && status === 'authenticated' && !open) {
        console.log('✅ Auto-opening modal after authentication');
        onOpenChange(true);
        // Очищаем параметр из URL
        params.delete('employment');
        const newUrl = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
        window.history.replaceState({}, '', newUrl);
      }
    }
  }, [status, open, onOpenChange]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Проверка авторизации
    if (status === 'loading') {
      toast.error('Подождите', {
        description: 'Проверяем авторизацию...',
      });
      return;
    }

    if (status === 'unauthenticated' || !session?.user) {
      toast.error('Требуется авторизация', {
        description: 'Пожалуйста, войдите через Discord перед подачей заявки',
      });
      return;
    }
    
    // Валидация
    if (!formData.firstName || !formData.lastName || !formData.static || !formData.reason) {
      toast.error('Ошибка', {
        description: 'Пожалуйста, заполните все обязательные поля',
      });
      return;
    }

    setLoading(true);

    try {
      console.log('📤 Submitting application...', formData);

      // Отправляем заявку
      const response = await fetch('/api/applications/employment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      console.log('📥 Response:', { status: response.status, data });

      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit application');
      }

      setSubmitted(true);

      toast.success('Успешно!', {
        description: 'Ваше заявление отправлено. Вы добавлены на Discord сервер и скоро получите сообщение от бота.',
        duration: 5000,
      });

      // Закрываем модальное окно через 3 секунды
      setTimeout(() => {
        onOpenChange(false);
        // Сбрасываем состояние
        setSubmitted(false);
        setFormData({
          firstName: '',
          lastName: '',
          static: '',
          reason: '',
        });
      }, 3000);
    } catch (error) {
      console.error('❌ Error submitting application:', error);
      toast.error('Ошибка', {
        description: error instanceof Error ? error.message : 'Не удалось отправить заявление. Попробуйте позже.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (!loading) {
      onOpenChange(false);
      setSubmitted(false);
      setFormData({
        firstName: '',
        lastName: '',
        static: '',
        reason: '',
      });
    }
  };

  // Если не авторизован - показываем кнопку входа
  if (status === 'unauthenticated') {
    return (
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <div className="flex items-center gap-2">
              <Briefcase className="h-5 w-5" />
              <DialogTitle>Заявление на трудоустройство</DialogTitle>
            </div>
          </DialogHeader>

          <div className="flex flex-col items-center justify-center py-8 space-y-4">
            <LogIn className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-lg font-semibold">Требуется авторизация</h3>
            <p className="text-sm text-muted-foreground text-center">
              Для подачи заявления необходимо войти через Discord
            </p>
            <Button onClick={() => {
              // Добавляем параметр в URL перед авторизацией
              const currentUrl = window.location.href;
              const separator = currentUrl.includes('?') ? '&' : '?';
              const callbackUrl = currentUrl + separator + 'employment=true';
              signIn('discord-public', { callbackUrl }); // ✅ Используем 'discord-public' (БЕЗ проверки роли EMS)
            }} className="mt-4">
              <LogIn className="mr-2 h-4 w-4" />
              Войти через Discord
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Briefcase className="h-5 w-5" />
            <DialogTitle>Заявление на трудоустройство</DialogTitle>
          </div>
          <DialogDescription>
            Заполните все обязательные поля. После отправки для вас будет создан отдельный канал.
          </DialogDescription>
        </DialogHeader>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">
                  Имя <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="firstName"
                  placeholder="Например: Иван"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="lastName">
                  Фамилия <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="lastName"
                  placeholder="Например: Иванов"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="static">
                Статик <span className="text-red-500">*</span>
              </Label>
              <Input
                id="static"
                placeholder="Например: 12345"
                value={formData.static}
                onChange={(e) => setFormData({ ...formData, static: e.target.value })}
                required
              />
              <p className="text-xs text-muted-foreground">
                Ваш внутренний идентификатор
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reason">
                Причина вступления <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="reason"
                placeholder="Расскажите, почему вы хотите присоединиться..."
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                rows={4}
                required
              />
            </div>

            {/* Индикатор статуса авторизации (только для отладки) */}
            {status === 'loading' && (
              <div className="text-sm text-muted-foreground">
                🔄 Проверка авторизации...
              </div>
            )}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                disabled={loading}
              >
                Отмена
              </Button>
              <Button type="submit" disabled={loading || status === 'loading'}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Отправка...
                  </>
                ) : (
                  'Отправить заявление'
                )}
              </Button>
            </DialogFooter>
          </form>
        ) : (
          <div className="flex flex-col items-center justify-center py-8">
            <CheckCircle2 className="h-16 w-16 text-green-500 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Заявление отправлено!</h3>
            <p className="text-sm text-muted-foreground text-center">
              Вы успешно добавлены на Discord сервер.<br />
              Ожидайте сообщения от бота с дальнейшими инструкциями.
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
