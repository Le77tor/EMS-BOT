'use client';

import { signOut } from 'next-auth/react';
import { Button } from './ui/button';
import {
  Bell,
  LogOut,
  User,
  ChevronDown,
} from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  user: {
    name?: string | null;
    email?: string | null;
    image?: string | null;
    role?: string;
    discordRoles?: any[] | null;
    discordId?: string;
  };
}

// Приоритетные роли (от высшей к низшей)
const PRIORITY_ROLES = [
  '1482048390157303914',
  '1482048390157303913',
  '1550078792813256754',
  '1518978875059732601',
  '1518626611921027244',
  '1518627545623560243',
  '1518978000459141200',
  '1518627502245806091',
  '1482048390148784238',
  '1516717575982153819',
  '1516719506997641237',
  '1516719580939157524',
  '1516719626497560626',
  '1516721666888302672',
  '1516721778934812794',
  '1516721813579628594',
  '1516721846945452085',
  '1516721885302231241',
  '1482048390148784230',
  '1482048390136070329',
  '1561397031262494891',
  '1482048390119555129',
  '1482048390136070328',
  '1482048390136070327',
  '1482048390136070326',
];

// Получить самую высокую роль пользователя
function getHighestRole(discordRoles?: any[] | null) {
  if (!discordRoles || !Array.isArray(discordRoles) || discordRoles.length === 0) {
    return null;
  }

  // Фильтруем служебные роли
  const filteredRoles = discordRoles.filter(
    (role: any) => role.name !== '@everyone' && !role.name.toLowerCase().includes('bot')
  );

  // Ищем первую роль из приоритетного списка
  for (const priorityRoleId of PRIORITY_ROLES) {
    const foundRole = filteredRoles.find((role: any) => role.id === priorityRoleId);
    if (foundRole) {
      return foundRole;
    }
  }

  // Если нет приоритетных ролей, возвращаем роль с наивысшей позицией
  const sortedByPosition = filteredRoles.sort((a: any, b: any) => b.position - a.position);
  return sortedByPosition[0] || null;
}

export function Header({ user }: HeaderProps) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  
  // Получаем самую высокую роль
  const highestRole = getHighestRole(user.discordRoles);
  const displayRole = highestRole ? highestRole.name : user.role;
  const roleColor = highestRole?.color ? `#${highestRole.color.toString(16).padStart(6, '0')}` : null;

  return (
    <header className="sticky top-0 z-30 w-full border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-16 items-center justify-between px-6">
        {/* Search */}
        <div className="flex-1 max-w-md">
          <div className="relative">
            <svg
              className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
            <input
              type="search"
              placeholder="Поиск..."
              className="h-10 w-full rounded-lg border-2 border-border bg-background pl-10 pr-4 text-sm transition-colors focus:border-primary focus:outline-none"
            />
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-3">
          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative rounded-lg hover:bg-accent"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-red-500 border-2 border-background" />
          </Button>

          {/* User menu */}
          <div className="relative">
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-accent transition-colors"
            >
              <div className="relative">
                {user.image ? (
                  <Image
                    src={user.image}
                    alt={user.name || 'User'}
                    width={36}
                    height={36}
                    className="rounded-full ring-2 ring-border"
                  />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm ring-2 ring-border">
                    {user.name?.charAt(0).toUpperCase() || 'U'}
                  </div>
                )}
                <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-green-500 border-2 border-background" />
              </div>
              <div className="hidden md:block text-left">
                <p className="text-sm font-semibold">{user.name}</p>
                {roleColor ? (
                  <p 
                    className="text-xs font-semibold"
                    style={{ color: roleColor }}
                  >
                    {displayRole}
                  </p>
                ) : (
                  <p className="text-xs text-muted-foreground">{displayRole}</p>
                )}
              </div>
              <ChevronDown className={cn(
                'h-4 w-4 text-muted-foreground transition-transform duration-200',
                isDropdownOpen && 'rotate-180'
              )} />
            </button>

            {/* Dropdown */}
            {isDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setIsDropdownOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-56 origin-top-right rounded-xl border-2 border-border bg-background shadow-2xl z-50 overflow-hidden">
                  <div className="p-3 border-b border-border bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20">
                    <p className="text-sm font-semibold">{user.name}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                  </div>
                  <div className="py-1">
                    {user.discordId ? (
                      <Link
                        href={`/users/${user.discordId}`}
                        className="flex w-full items-center gap-3 px-4 py-2.5 text-sm hover:bg-accent transition-colors"
                        onClick={() => setIsDropdownOpen(false)}
                      >
                        <User className="h-4 w-4" />
                        Профиль
                      </Link>
                    ) : (
                      <button className="flex w-full items-center gap-3 px-4 py-2.5 text-sm hover:bg-accent transition-colors">
                        <User className="h-4 w-4" />
                        Профиль
                      </button>
                    )}
                  </div>
                  <div className="border-t border-border py-1">
                    <button
                      onClick={() => signOut({ callbackUrl: '/login' })}
                      className="flex w-full items-center gap-3 px-4 py-2.5 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/20 transition-colors"
                    >
                      <LogOut className="h-4 w-4" />
                      Выйти
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
