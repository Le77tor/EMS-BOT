'use client';

import * as React from 'react';
import { toast as sonnerToast } from 'sonner';

export function Toaster() {
  return null;
}
