'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

interface TransferModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const DEPARTMENTS = [
  { value: 'DI', label: 'DI', emoji: '🔍' },
  { value: 'HAD', label: 'HAD', emoji: '⚕️' },
  { value: 'PSED', label: 'PSED', emoji: '🚨' },
  { value: 'DES', label: 'DES', emoji: '📚' },
  { value: 'PM', label: 'PM', emoji: '🏛️' },
];

export function TransferModal({ open, onOpenChange }: TransferModalProps) {
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  const [formData, setFormData] = useState({
    targetDepartment: '',
    online: '',
    schedule: '',
    experience: '',
    motivation: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!session?.user?.id) {
      toast.error('Вы не авторизованы');
      return;
    }

    if (!formData.targetDepartment) {
      toast.error('Выберите отдел для перевода');
      return;
    }

    if (!formData.online || !formData.schedule || !formData.experience || !formData.motivation) {
      toast.error('Заполните все обязательные поля');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: session.user.id,
          targetDepartment: formData.targetDepartment,
          online: formData.online,
          schedule: formData.schedule,
          experience: formData.experience,
          motivation: formData.motivation,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Ошибка при отправке заявки');
      }

      setSubmitted(true);
      toast.success('Заявка на перевод успешно отправлена!');
      
      setTimeout(() => {
        onOpenChange(false);
        setTimeout(() => {
          setSubmitted(false);
          setFormData({
            targetDepartment: '',
            online: '',
            schedule: '',
            experience: '',
            motivation: '',
          });
        }, 300);
      }, 2000);
    } catch (error: any) {
      console.error('Ошибка отправки заявки на перевод:', error);
      toast.error(error.message || 'Не удалось отправить заявку на перевод');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (!loading) {
      onOpenChange(false);
      setTimeout(() => {
        setSubmitted(false);
        setFormData({
          targetDepartment: '',
          online: '',
          schedule: '',
          experience: '',
          motivation: '',
        });
      }, 300);
    }
  };

  if (submitted) {
    return (
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[500px]">
          <div className="flex flex-col items-center justify-center py-8">
            <div className="mb-4 rounded-full bg-green-100 dark:bg-green-950 p-3">
              <CheckCircle2 className="h-12 w-12 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="mb-2 text-xl font-bold">Заявка отправлена!</h3>
            <p className="text-center text-muted-foreground mb-4">
              Ваша заявка на перевод успешно отправлена.<br />
              Ожидайте рассмотрения от руководства обоих отделов.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            🔄 Заявка на перевод между отделами
          </DialogTitle>
          <DialogDescription>
            Заполните форму для подачи заявки на перевод в другой отдел
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Выбор целевого отдела */}
          <div className="space-y-2">
            <Label htmlFor="targetDepartment">
              Целевой отдел <span className="text-red-500">*</span>
            </Label>
            <Select
              value={formData.targetDepartment}
              onValueChange={(value) => setFormData({ ...formData, targetDepartment: value })}
              disabled={loading}
            >
              <SelectTrigger id="targetDepartment">
                <SelectValue placeholder="Выберите отдел для перевода" />
              </SelectTrigger>
              <SelectContent>
                {DEPARTMENTS.map((dept) => (
                  <SelectItem key={dept.value} value={dept.value}>
                    <span className="flex items-center gap-2">
                      <span>{dept.emoji}</span>
                      <span>{dept.label}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Онлайн */}
          <div className="space-y-2">
            <Label htmlFor="online">
              Онлайн (Часов в сутки) <span className="text-red-500">*</span>
            </Label>
            <Input
              id="online"
              placeholder="Например: 8-10 часов"
              value={formData.online}
              onChange={(e) => setFormData({ ...formData, online: e.target.value })}
              disabled={loading}
              maxLength={50}
              required
            />
          </div>

          {/* Часы игры */}
          <div className="space-y-2">
            <Label htmlFor="schedule">
              Часы игры (МСК) <span className="text-red-500">*</span>
            </Label>
            <Input
              id="schedule"
              placeholder="Например: 14:00 - 22:00"
              value={formData.schedule}
              onChange={(e) => setFormData({ ...formData, schedule: e.target.value })}
              disabled={loading}
              maxLength={50}
              required
            />
          </div>

          {/* Опыт в отделе */}
          <div className="space-y-2">
            <Label htmlFor="experience">
              Опыт в текущем отделе <span className="text-red-500">*</span>
            </Label>
            <Textarea
              id="experience"
              placeholder="Расскажите о вашем опыте работы в текущем отделе..."
              value={formData.experience}
              onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
              disabled={loading}
              className="min-h-[100px] resize-none"
              minLength={20}
              maxLength={1000}
              required
            />
            <p className="text-xs text-muted-foreground">
              Минимум 20 символов, максимум 1000 ({formData.experience.length}/1000)
            </p>
          </div>

          {/* Мотивация */}
          <div className="space-y-2">
            <Label htmlFor="motivation">
              Мотивация <span className="text-red-500">*</span>
            </Label>
            <Textarea
              id="motivation"
              placeholder="Почему вы хотите перейти в этот отдел?"
              value={formData.motivation}
              onChange={(e) => setFormData({ ...formData, motivation: e.target.value })}
              disabled={loading}
              className="min-h-[100px] resize-none"
              minLength={20}
              maxLength={1000}
              required
            />
            <p className="text-xs text-muted-foreground">
              Минимум 20 символов, максимум 1000 ({formData.motivation.length}/1000)
            </p>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={loading}
            >
              Отмена
            </Button>
            <Button 
              type="submit" 
              disabled={loading}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Отправка...
                </>
              ) : (
                'Отправить заявку'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
