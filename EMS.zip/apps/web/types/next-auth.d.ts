import { DefaultSession, DefaultUser } from 'next-auth';
import { JWT, DefaultJWT } from 'next-auth/jwt';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      role: string;
      status: string;
      discordId: string;
      username: string;
      displayName: string;
      discordRoles: Array<{
        id: string;
        name: string;
        color: number;
        position: number;
      }> | null;
    } & DefaultSession['user'];
  }

  interface User extends DefaultUser {
    role: string;
    status: string;
    discordId: string;
    username: string;
    displayName: string;
    avatar: string | null;
    discordRoles: Array<{
      id: string;
      name: string;
      color: number;
      position: number;
    }> | null;
  }
}

declare module 'next-auth/jwt' {
  interface JWT extends DefaultJWT {
    id: string;
    role: string;
    status: string;
    discordId: string;
    username: string;
    displayName: string;
    avatar: string | null;
    discordRoles: Array<{
      id: string;
      name: string;
      color: number;
      position: number;
    }> | null;
  }
}
