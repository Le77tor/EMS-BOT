import { PrismaClient } from '@prisma/client';

declare global {
  // eslint-disable-next-line no-var
  var prisma: PrismaClient | undefined;
}

export const prisma = global.prisma || new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
});

// Always cache Prisma Client globally to prevent multiple instances
if (!global.prisma) {
  global.prisma = prisma;
}

export * from '@prisma/client';
